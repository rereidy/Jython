#################################
#
#   File:    list_comp1.py
#
#   Description
#
#   Demonstrate list comprehension
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause

print """
*********
notprimes = [j for i in range(2, 8) for j in range(i*2, 50, i)]
print "notprime: ", notprimes
primes = [x for x in range(2, 50) if x not in notprimes]
print "prime: ", primes

cel = [39.2, 29, 50, 15]
far = [((float(9)/5) * x + 32) for x in cel]
print "Farenheit: ", far
*********
"""

notprimes = [j for i in range(2, 8) for j in range(i*2, 50, i)]
print "notprime: ", notprimes
primes = [x for x in range(2, 50) if x not in notprimes]
print "prime: ", primes

cel = [39.2, 29, 50, 15]
far = [((float(9)/5) * x + 32) for x in cel]
print "Farenheit: ", far

pause()

print """
*********
v = [ 2*x+1 for x in range(10) if x%3==0 ]
print "[ 2*x+1 for x in range(10) if x%3==0 ] =", v, " and is a", type(v)

v2 = [ 2*x+1 for x in range(10) if x%3==0 or x%2!=0 ]
print "[ 2*x+1 for x in range(10) if x%3==0 or x%2!=0 ] =", v2, " and is a", type(v2)
*********
"""

v = [ 2*x+1 for x in range(10) if x%3==0 ]
print "[ 2*x+1 for x in range(10) if x%3==0 ] =", v, " and is a", type(v)

v2 = [ 2*x+1 for x in range(10) if x%3==0 or x%2!=0 ]
print "[ 2*x+1 for x in range(10) if x%3==0 or x%2!=0 ] =", v2, " and is a", type(v2)
