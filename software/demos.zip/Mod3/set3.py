#################################
#
#   File:   set3.py
#
#   Description
#
#   Demonstrate set comprehension
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********    
test = {p ** 2 for p in range(11)}
for t in test:
    print "t =", t
    print "t is a ", type(t)
*********
"""

from ver2_6 import v2_6

v2_6()
    
test = {p ** 2 for p in range(11)}
for t in test:
    print "t =", t
    print "t is a ", type(t)
