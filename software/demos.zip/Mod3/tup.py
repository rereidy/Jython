#################################
#
#   File:   tup.py
#
#   Description
#
#   Demonstrate tuple type
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause

print """
*********
t = 12345, 54321, 'test    #number of values separated by comma ","
print "t =", t, " and is a ", type(t)
*********
"""

t = 12345, 54321, 'test'
print "t =", t, " and is a ", type(t)

pause()

print """
*********
indexing and slicing

print "t[0] =", t[0], " and is a ", type(t[0])
print "t[2:3] =", t[2:3], " and is a", type(t[2:3])
print "t[-2] =", t[-2], " and is a", type(t[-2])
*********
"""

print "t[0] =", t[0], " and is a ", type(t[0])
print "t[2:3] =", t[2:3], " and is a", type(t[2:3])
print "t[-2] =", t[-2], " and is a", type(t[-2])

pause()

print """
*********
not mutable

try:
    t[0] = -1
except TypeError, e:
    print e
*********
"""

try:
    t[0] = -1
except TypeError, e:
    print e
    
pause()

print """
*********
can contain mutable objects

tm = -1, 0, ['a', 'b']
print "tm =", tm, " and is a", type(tm)

print "concatenate ['c', 'd'] to", tm[2],
tm[2] += ['c', 'd']                        throws exception - cannot change the mutable type
print "=", tm[2]

*********
"""

tm = -1, 0, ['a', 'b']
print "tm =", tm, " and is a", type(tm)

print "concatenate ['c', 'd'] to", tm[2],
tm[2] += ['c', 'd']
print "=", tm[2]