#################################
#
#   File:    deque1.py
#
#   Description
#
#   Demonstrate collectins.dequeu
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause
from ver2_6 import v2_6

v2_6()

print """
*********
import collections
from pprint import pprint

d = collections.deque('abcdefg')
print 'Deque ==> ', 
pprint(d)
print 'Length:', len(d)
print 'Left end:', d[0]
print 'Right end:', d[-1]

d.remove('c')
print 'remove(c) ==> ', 
pprint(d)
*********
"""

import collections
from pprint import pprint

d = collections.deque('abcdefg')
print 'Deque ==> ', 
pprint(d)
print 'Length:', len(d)
print 'Left end:', d[0]
print 'Right end:', d[-1]

d.remove('c')
print 'remove(c) ==> ', 
pprint(d)

pause()

print """
*********
Consumption

print 'From the right:'
d = collections.deque('abcdefg')
print "len of d=", len(d)
pprint(d)

print "pop()"
while True:
    try:
        print d.pop()
        print "len of d=", len(d)
        pprint(d)
    except IndexError:
        break

print '\nFrom the left:'
d = collections.deque('abcdefg')
print "len of d=", len(d)
pprint(d)

print "popleft()"
while True:
    try:
        print d.popleft()
        print "len of d=", len(d)
        pprint(d)
*********
"""

d = collections.deque('abcdefg')
print "len of d=", len(d)
pprint(d)

print "pop()"
while True:
    try:
        print d.pop()
        print "len of d=", len(d)
        pprint(d)
    except IndexError:
        break

pause()

d = collections.deque('abcdefg')
print "len of d=", len(d)
pprint(d)

print "popleft()"
while True:
    try:
        print d.popleft()
        print "len of d=", len(d)
        pprint(d)
    except IndexError:
        break

pause()

print """
*********
Rotate and skip items
*********
"""

d = collections.deque(xrange(10))
print 'Normal        :', 
pprint(d)

d = collections.deque(xrange(10))
d.rotate(2)
print 'Right rotation:', 
pprint(d)

d = collections.deque(xrange(10))
d.rotate(-2)
print 'Left rotation :', 
pprint(d)
