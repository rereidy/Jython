#################################
#
#   File:    floats.py
#
#   Description
#
#   Demonstrate float type
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

f1 = 1.

print "f1=", f1, " and is a", type(f1)

print "float(2)=",float(2), " and is a ", type(float(2))

print "float(3L)=",float(3L), " and is a", type(float(3L))

print "\nformatting"
print "f1 = %%f: f1 = %f" %f1
print "f1 = %%.2f: f1 = %.2f" %f1