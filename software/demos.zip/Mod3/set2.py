#################################
#
#   File:   set2.py
#
#   Description
#
#   Demonstrate set operations part2
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
S = set(range(4))
print "S =", S
S.add(5)
print "S (after in place add) =", S
*********
"""

from pause import pause
from ver2_6 import v2_6

v2_6()

S = set(range(4))
print "S =", S
S.add(5)
print "S (after in place add) =", S

pause()

print """
*********
S.update(set(range(6,10)))
print "S after update(): ", S
*********
"""

S.update(set(range(6,10)))
print "S after update(): ", S

pause()

print """
*********
intersection

print "S intersection with [-1, 0, 8]: ", set(S).intersection(set([-1, 0, 8])), " and is a", type(set(S).intersection(set([-1, 0, 8])))
*********
"""

print "S intersection with [-1, 0, 8]: ", set(S).intersection(set([-1, 0, 8])), " and is a", type(set(S).intersection(set([-1, 0, 8])))
pause()

print """
*********
removal

S.remove(0)
print "S after remove '0': ", S
*********
"""

S.remove(0)
print "S after remove '0': ", S

pause()

print """
*********
S2 = frozenset(range(-10,0))
print "frozenset S2 =", S2

try:
    S2.add(0)
except AttributeError, e:
    print "Exception: ", e
*********
"""

S2 = frozenset(range(-10,0))
print "frozenset S2 =", S2

try:
    S2.add(0)
except AttributeError, e:
    print "Exception: ", e