#################################
#
#   File:    print1.py
#
#   Description
#
#    Demonstrate base printing capability
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################


print """
*********
print always appends newline

print ">test<"
*********
"""
from pause import pause

print ">test<"

pause()

print """
********
print w/o newline

print "test",    # no newline
print "after"
********
"""

print "test",
print "after"

pause()

print """
*********
import sys
sys.stdout.write("write to stdout\\n")    # does not work in Jython 2.5; works in Jython 2.7
sys.stderr.write("write to stderr\\n")
*********
"""

import sys
sys.stdout.write("write to stdout\n")
sys.stderr.write("write to stderr\n")

pause()

print """
*********
print >> sys.stdout, "redirect to stdout"
print >> sys.stderr, "redirect to stderr"
*********
"""

print >> sys.stdout, "redirect to stdout"
print >> sys.stderr, "redirect to stderr"