#################################
#
#   File:    file2.py
#
#   Description
#
#    Demonstrate binary file operations
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import struct

bf = open('/Users/rereidy/Documents/workspace/Jython/class/demos/Mod3/file2.bin', 'w')
for r in range(10):
    dat = struct.pack('i', r)
    print "numeral %d converted to %r" %(r, dat)
    bf.write(dat)
bf.close()
*********
"""

import struct

from pause import pause

bf = open('/Users/rereidy/Documents/workspace/Jython/class/demos/Mod3/file2.bin', 'w')
for r in range(10):
    dat = struct.pack('i', r)
    print "numeral %d converted to %r" %(r, dat)
    bf.write(dat)
bf.close()

pause()

print """
*********
def rdbin():
    bf = open("/Users/rereidy/Documents/workspace/Jython/class/demos/Mod3/file2.bin", "rb")

    intsz = struct.calcsize('i')

    print "intsz =", intsz

    while 1:
        dat = bf.read(intsz)
        if dat == "":
            break
        n = struct.unpack('i', dat)                        # returns a tuple
        print "nunmber from '%s' = %d" %(bf.name, n[0])    # the first element of the tuple will have the number unpack()ed

    bf.close()

rdbin()
*********
"""

def rdbin():
    bf = open("/Users/rereidy/Documents/workspace/Jython/class/demos/Mod3/file2.bin", "rb")

    intsz = struct.calcsize('i')

    print "intsz =", intsz

    while 1:
        dat = bf.read(intsz)
        if dat == "":
            break
        n = struct.unpack('i', dat)
        print "nunmber from '%s' = %d" %(bf.name, n[0])

    bf.close()

rdbin()

pause()

print """
*********
bf = open("/Users/rereidy/Documents/workspace/Jython/class/demos/Mod3/file2.bin", "ab")
for r in range(10, 21):
    d = struct.pack('i', r)
    print "numeral %d converted to %r" %(r, dat)
    bf.write(r)

bf.close

rdbin()
*********
"""

bf = open("/Users/rereidy/Documents/workspace/Jython/class/demos/Mod3/file2.bin", "ab")
print "appending to file"
for r in range(10, 21):
    d = struct.pack('i', r)
    print "numeral %d converted to %r" %(r, d)
    bf.write(d)

bf.close()

print "new file contents"
rdbin()