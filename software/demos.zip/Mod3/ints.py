#################################
#
#   File:    ints.py
#
#   Description
#
#    Demonstrate integer type
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
i = 1
print 'i=',i

print "oct eval('0010')=", eval('010')
print "oct eval('0011')=", eval('0011')

h = 0x17

print "hexidecimal 17 =", h # decimal notation
print "hexidecimal 17 = %x" %h  #hex notation

print "formatting:"
print "i = %%d: i=%d" %i
print "i = %%02d: i = %02d" %i
*********
"""

i = 1

print "i=", i

print "oct eval('0010')=", eval('010')
print "oct eval('0011')=", eval('0011')

h = 0x17

print "hexidecimal 17 =", h
print "hexidecimal 17 = %x" %h

print "\nformatting:"
print "i = %%d: i=%d" %i
print "i = %%02d: i = %02d" %i
