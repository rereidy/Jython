#################################
#
#   File:   list1.py
#
#   Description
#
#   Demonstrate list type
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
List type demo

L = [1,2,3]
print "L is a", type(L)
print "L =", L
print "len(L) =", len(L)
*********
"""

from pause import pause

L = [1,2,3]
print "L is a", type(L)
print "L =", L
print "len(L) =", len(L)

pause()

print """
*********
L1 = [1,2,3,4]
L2 = [5,6,7,8]

print "L1 =", L1
print "L2 =", L2

print "concatenate: L1 + L2 =", L1 + L2
*********
"""

L1 = [1,2,3,4]
L2 = [5,6,7,8]

print "L1 =", L1
print "L2 =", L2

print "concatenate: L1 + L2 =", L1 + L2

pause()

print """
*********
Indexing and slicing

L3 = ['Ron', 'plays', 'golf']
print "L3 =", L3
print "L3[2] =", L3[2], "          ^^^^ ==> offsets start at 0"
try:
    print "L3[3] =", L3[3]
except IndexError, e:
    print e
    
print "L3[-1] =", L3[-1]    # negative indexes count back from right

try:
    print "L3[-4] =", L3[-4]
except IndexError, e:
    print e
*********
"""

L3 = ['Ron', 'plays', 'golf']
print "L3 =", L3
print "L3[2] =", L3[2], "          ^^^^ ==> offsets start at 0"
try:
    print "L3[3] =", L3[3]
except IndexError, e:
    print e

print "L3[-1] =", L3[-1]

try:
    print "L3[-4] =", L3[-4]
except IndexError, e:
    print e

pause()

print """
*********
Matrix operations

L4 = [[1,2,3], [4,5,6], [7,8,9]]
print "L4 =", L4
print "L4 is a ", type(L4)

print "L4[0] =", L4[0]
print "L4[0] is a ", type(L4[0])

print "L4[0][0] =", L4[0][0]
print "L4[0][0] is a", type(L4[0][0])
*********
"""

L4 = [[1,2,3], [4,5,6], [7,8,9]]
print "L4 =", L4
print "L4 is a ", type(L4)

print "L4[0] =", L4[0]
print "L4[0] is a ", type(L4[0])

print "L4[0][0] =", L4[0][0]
print "L4[0][0] is a", type(L4[0][0])

