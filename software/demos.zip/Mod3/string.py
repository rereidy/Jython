#################################
#
#   File:    string.py
#
#   Description
#
#   Demonstrate sring functions
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause

print """
*********
s1 = "test"
print "s1 = ", s1, "at", hex(id(s1))
*********
"""


s1 = "test"
print "s1 = ", s1, "at", hex(id(s1))

pause()

print """
*********
print "s1.replace('est', 'rip') = ", s1.replace("est", "rip") 

print "s1.upper:", s1.upper(), " and lower:", s1.lower()
print "s1.find('xx'):", s1.find('xx')            # will return -1 (not found)
*********
"""

print "s1.replace('est', 'rip') = ", s1.replace("est", "rip") 

print "s1.upper:", s1.upper(), " and lower:", s1.lower()
print "s1.find('xx'):", s1.find('xx')

pause()

print """
*********
s1 = "   >test<   "
print "s1 = '%s'" %s1

print "s1.strip(): '%s'" %s1.strip()
print "s1.lstrip(): '%s'" %s1.lstrip(), " and s1.rstrip(): '%s'" %s1.rstrip()
*********
"""

s1 = "   >test<   "
print "s1 = '%s'" %s1

print "s1.strip(): '%s'" %s1.strip()
print "s1.lstrip(): '%s'" %s1.lstrip(), " and s1.rstrip(): '%s'" %s1.rstrip()

pause()

print """
*********
s1 = "now is the time"
print "s1 = '%s'" %s1
print "s1.split(' '): ", ', '.join(s1.split(' '))
*********
"""

s1 = "now is the time"
print "s1 = '%s'" %s1
print "s1.split(' '): ", ', '.join(s1.split(' '))

pause()

print """
*********
s1 = range(ord('a'), ord('d'))
print "s1 =", s1, " and is a", type(s1)

## list comprehension
print "'-'.join([str(x) for x in s1]) = ", '-'.join([str(x) for x in s1]), " and is a", type('-'.join([str(x) for x in s1]))
print "'-'.join([chr(x) for x in s1]) = ", '-'.join([chr(x) for x in s1]), " and is a", type('-'.join([chr(x) for x in s1]))
*********
"""

s1 = range(ord('a'), ord('d'))
print "s1 =", s1, " and is a", type(s1)
print "'-'.join([str(x) for x in s1]) = ", '-'.join([str(x) for x in s1]), " and is a", type('-'.join([str(x) for x in s1]))
print "'-'.join([chr(x) for x in s1]) = ", '-'.join([chr(x) for x in s1]), " and is a", type('-'.join([chr(x) for x in s1]))
