#################################
#
#   File:    file1.py
#
#   Description
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
f = open("ACKNOWLEDGMENTS", "r")
print "f is a ", type(f), " and f is open: ", f.closed()
*********
"""

from pause import pause

f = open("ACKNOWLEDGMENTS", "r")
print "f is a ", type(f), " and f is open: ", f.closed

pause()

print """
*********
for line in f.readlines():
    print line.rstrip("\n")
*********
"""

for line in f.readlines():
    print line.rstrip("\n")

print "f is open: ", f.closed

f.close()

pause()

print """
*********
You can also read lines using the built-in iter() function

for line in iter(f):
    print line.rstrip('\n')
*********
"""

f = open("ACKNOWLEDGMENTS", "r")
for line in iter(f):
    print line.rstrip('\n')
