#################################
#
#   File:    longs.py
#
#   Description
#
#    Demonstrate long type
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

l = 1l

print "l is", type(l)

print "long(2) =", long(2), " and is a", type(long(2))

print "\nformating"
print "l = %%d: l = %d" %l
print "l = %%02d: l = %02d" %l