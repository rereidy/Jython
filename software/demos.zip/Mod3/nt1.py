#################################
#
#   File:    nt1.py
#
#   Description
#
#   Demonstrate namedtuple
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from ver2_6 import v2_6

v2_6()

print """
*********
import collections

Car = collections.namedtuple('Car', 'make model year')

print 'Type of Car:', type(Car)

bmw = Car(make='BMW', model='530i', year=2015)
print '\nRepresentation:', bmw

dodge = Car(make='Dodge', model='Challenger', year=2015)
print '\nField by make:', dodge.make, dodge.model, dodge.year

print '\nFields by index:'
for p in [ bmw, dodge ]:
    print '%s - %s %d' % p
*********
"""

import collections

Car = collections.namedtuple('Car', 'make model year')

print 'Type of Car:', type(Car)

bmw = Car(make='BMW', model='530i', year=2015)
print '\nRepresentation:', bmw

dodge = Car(make='Dodge', model='Challenger', year=2015)
print '\nField by make:', dodge.make, dodge.model, dodge.year

print '\nFields by index:'
for p in [ bmw, dodge ]:
    print '%s - %s %d' % p

