#################################
#
#   File:    glob1.py
#
#   Description
#
#    Demonstrate glob module
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import glob

for f in glob.glob("*.*"):
    print "file: %s" %f
*********
"""

from pause import pause

import glob

for f in glob.glob("*.*"):
    print "file: %s" %f
    
pause()

print """
*********
from os.path import isdir, isfile, islink
for f in glob.glob("*.*"):
    msg = None
    if isdir(f):
        msg = "file: %s is a directory" %f
    elif isfile(f):
        msg = "file: %s is a regular file" %f
    elif islink(f):
        msg = "file: %s is a link" %f
    else:
        msg = "file: %s is an unknown type" %f
    
    print msg
*********
"""

from os.path import isdir, isfile, islink
for f in glob.glob("*.*"):
    msg = None
    if isdir(f):
        msg = "file: %s is a directory" %f
    elif isfile(f):
        msg = "file: %s is a regular file" %f
    elif islink(f):
        msg = "file: %s is a link" %f
    else:
        msg = "file: %s is an unknown type" %f
    
    print msg