#################################
#
#   File:    complex.py
#
#   Description
#
#    Demonstrate complex numbers
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
How it works ...
a = complex(0,1)
print "a.real=",a.real
print "a.imag=",a.imag
print "abs(a): ", abs(a), " and is a", type(abs(a))

b = complex(-1,0)
print "b.real=",b.real
print "b.imag=",b.imag
print "abs(b): ", abs(b), " and is a", type(abs(b))

print "a * b"
real_part = a.real*b.real - a.imag*b.imag
imag_part = a.real*b.imag + a.imag*b.real

print "(real,imag) = (%f,%f)" %(real_part, imag_part)
*********
"""

a = complex(0,1)
print "a is a", type(a)
print "a.real=",a.real
print "a.imag=",a.imag
print "abs(a): ", abs(a), " and is a", type(abs(a))

b = complex(-1,0)
print "b.real=",b.real
print "b.imag=",b.imag
print "abs(b): ", abs(b), " and is a", type(abs(b))

print "a*b"
print "a*b: ", a*b, " and is a", type(a*b)
real_part = a.real*b.real - a.imag*b.imag
imag_part = a.real*b.imag + a.imag*b.real

print "(real,imag) = %f,%f" %(real_part, imag_part)