#################################
#
#   File:    dict1.py
#
#   Description
#
#    Demonstrate dictionary type
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
dictionary methods

from pause import pause

D = {'Jython' : 1, 'Python' : 2, 'Perl' : 3, 'Java' : 4, 'C++' : 5}

print "fetch value by key: D['Jython'] =", D['Jython']
*********
"""

from pause import pause

D = {'Jython' : 1, 'Python' : 2, 'Perl' : 3, 'Java' : 4, 'C++' : 5}

print "D =", D
print "D is a ", type(D)

print "fetch value by key: D['Jython'] =", D['Jython']
    
pause()

print """
*********
print "D = ", D
print "D is a ", type(D)

print "values =", list(D.values())

print "items =", list(D.items())

for d in D.items():            # items returns a Tuple
    print "d is a ", type(d)
    print "d =", d
    
for dl in list(D.items()):    # no difference from last loop
    print "dl = ", dl
    print "dl is a ", type(dl)
*********
"""

print "D = ", D
print "D is a ", type(D)

print "values =", list(D.values())

print "items =", list(D.items())

pause()

for d in D.items():
    print "d is a ", type(d)
    print "d =", d

pause()
    
for dl in list(D.items()):
    print "dl = ", dl
    print "dl is a ", type(dl)

pause()

print """
*********
change in place

D['C'] = 5                        # add a new entry in the dictionary
print "D['C'] =", D['C']
print "D[C] is a ", type(D['C'])

D['C'] = "test"                    # change an existing entry
print "D['C'] =", D['C']
print "D[C] is a ", type(D['C'])
*********
"""

D['C'] = 5
print "after add:", D
print "D['C'] =", D['C']
print "D['C'] is a ", type(D['C'])

D['C'] = "test"
print "D['C'] =", D['C']
print "D['C'] is a ", type(D['C'])

print "del D['C']"
try:
    del D['C']
    print "after delete:", D
except KeyError, e:
    print e

