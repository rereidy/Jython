#################################
#
#   File:    frac.py
#
#   Description
#
#   Demonstrate the fractions module in Jython2.7
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
frac.py - demonstrate Fractions in Python 2.6 and up

import fractions

f1 = fractions.Fraction(20, -10)    # normalized during construction by calling gcd() and dividing each argument by that result
f1 = fractions.Fraction(20, -10)
print "f1 =", f1
print "f1 is a", type(f1)
print "gcd(20, -10) =", fractions.gcd(20, -10)
print "f1.numerator =", f1.numerator
print "f1.denominator =", f1.denominator
*********
"""

from ver2_6 import v2_6
from pause import pause

v2_6()

import fractions

f1 = fractions.Fraction(20, -10)
print "f1 =", f1
print "f1 is a", type(f1)
print "gcd(20, -10) =", fractions.gcd(20, -10)
print "f1.numerator =", f1.numerator
print "f1.denominator =", f1.denominator

pause()

print """
*********
default constructor - no args

f2 = fractions.Fraction()    # defaults to Fraction(0, 1)
print "f2 =", f2
print "f2 is a", type(f2)
print "f2.numerator =", f2.numerator
print "f2.denominator =", f2.denominator
*********
"""

f2 = fractions.Fraction()
print "f2 =", f2
print "f2 is a", type(f2)
print "f2.numerator =", f2.numerator
print "f2.denominator =", f2.denominator

pause()

print """
*********
integer argument

f3 = fractions.Fraction(123)    # denominator defaults to 1
print "f3 =", f3
print "f3 is a", type(f3)
print "f3.numerator =", f3.numerator
print "f3.denominator =", f3.denominator
*********
"""

f3 = fractions.Fraction(123)
print "f3 =", f3
print "f3 is a", type(f3)
print "f3.numerator =", f3.numerator
print "f3.denominator =", f3.denominator

pause()

print """
*********
float argument

f4 = fractions.Fraction(1.1)
print "f4 =", f4
print "f4 is a", type(f4)
print "f4.numerator =", f4.numerator
print "f4.denominator =", f4.denominator
*********
"""

f4 = fractions.Fraction(1.1)
print "f4 =", f4
print "f4 is a", type(f4)
print "f4.numerator =", f4.numerator
print "f4.denominator =", f4.denominator

pause()

print """
*********
string arguments

f5 = fractions.Fraction('2/7')
print "f5 =", f5
print "f5 is a", type(f5)
print "f5.numerator =", f5.numerator
print "f5.denominator =", f5.denominator
*********
"""

f5 = fractions.Fraction('2/7')
print "f5 =", f5
print "f5 is a", type(f5)
print "f5.numerator =", f5.numerator
print "f5.denominator =", f5.denominator

pause()

print """
*********
Fraction argument

f6 = fractions.Fraction(f1)
print "f6 =", f6
print "f6 is a", type(f6)
print "f6.numerator =", f6.numerator
print "f6.denominator =", f6.denominator
*********
"""

f6 = fractions.Fraction(f1)
print "f6 =", f6
print "f6 is a", type(f6)
print "f6.numerator =", f6.numerator
print "f6.denominator =", f6.denominator

pause()

print """
*********
Decimal argument

from decimal import Decimal 

f7 = fractions.Fraction(Decimal('3.1'))
print "f7 =", f7
print "f7 is a", type(f7)
print "f7.numerator =", f7.numerator
print "f7.denominator =", f7.denominator
*********
"""

from decimal import Decimal 

f7 = fractions.Fraction(Decimal('3.1'))
print "f7 =", f7
print "f7 is a", type(f7)
print "f7.numerator =", f7.numerator
print "f7.denominator =", f7.denominator

pause()

print """
*********
limiting the denominator

from math import pi

f8 = fractions.Fraction(pi).limit_denominator(100)
print "f8 =", f8
print "f8 is a", type(f8)
print "f8.numerator =", f8.numerator
print "f8.denominator =", f8.denominator
*********
"""

from math import pi

f8 = fractions.Fraction(pi).limit_denominator(100)
print "f8 =", f8
print "f8 is a", type(f8)
print "f8.numerator =", f8.numerator
print "f8.denominator =", f8.denominator

print """
*********
ZeroDivisionError

fractions.Fraction(1/0)
*********
"""

fractions.Fraction(1/0)