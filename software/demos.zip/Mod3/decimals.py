#################################
#
#   File:    decimals.py
#
#   Description
#
#    Demonstrate decimals type
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
decimal.getcontext().prec = 28
decimal.Decimal(10)
decimal.Decimal('3.14')
decimal.Decimal(3.14)
decimal.Decimal((0, (3, 1, 4), -2))
decimal.Decimal(str(2.0 ** 0.5))
decimal.Decimal(2) ** decimal.Decimal('0.5')
decimal.Decimal('NaN')
decimal.Decimal('-Infinity')
decimal.Decimal(Infinity)
*********
"""

import decimal

decimal.getcontext().prec = 28
print "decimal.Decimal(10):", decimal.Decimal(10), "and is a", type(decimal.Decimal(10))
print "decimal.Decimal('3.14'):", decimal.Decimal('3.14'), "and is a", type(decimal.Decimal('3.14'))
print "decimal.Decimal(3.14):", decimal.Decimal(3.14), "and is a", type(decimal.Decimal(3.14))
print "decimal.Decimal((0, (3, 1, 4), -2)):", decimal.Decimal((0, (3, 1, 4), -2)), "and is a", type(decimal.Decimal((0, (3, 1, 4), -2)))
print "decimal.Decimal(str(2.0 ** 0.5)):", decimal.Decimal(str(2.0 ** 0.5)), "and is a", type(decimal.Decimal(str(2.0 ** 0.5)))
print "decimal.Decimal(2) ** decimal.Decimal('0.5'):", decimal.Decimal(2) ** decimal.Decimal('0.5'), "and is a", type(decimal.Decimal(2) ** decimal.Decimal('0.5'))
print "decimal.Decimal('NaN'):", decimal.Decimal('NaN'), "and is a", type(decimal.Decimal('NaN'))
print "decimal.Decimal('-NaN'):", decimal.Decimal('-NaN'), "and is a", type(decimal.Decimal('-NaN'))
print "decimal.Decimal('-Infinity'):", decimal.Decimal('-Infinity'), " and is a", type(decimal.Decimal('-Infinity'))
print "decimal.Decimal(Infinity):", decimal.Decimal('Infinity'), "and is a", type(decimal.Decimal('Infinity'))
print "decimal.Decimal(0):", decimal.Decimal(0), " and is a", type(decimal.Decimal(0))
print "decimal.Decimal(-0):", decimal.Decimal(-0), " and is a", type(decimal.Decimal(-0))