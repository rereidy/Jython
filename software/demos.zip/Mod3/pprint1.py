print """
*********
import pprint

L = ['one', 2, 'tres', 4, (1,2,3,4), {1: 'one', 2: 'two', 's': "string"}, range(5)]
print "L =", L
pprint.pprint(L)
*********
"""

import pprint

L = ['one', 2, 'tres', 4, (1,2,3,4), {1: 'one', 2: 'two', 's': "string"}, range(5)]
print "L = ", L
pprint.pprint(L)
