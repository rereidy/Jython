#################################
#
#   File:    counter1.py
#
#   Description
#
#   Demonstrate counter collection
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause
from ver2_6 import v2_6
v2_6()

print """
import collections

print collections.Counter(['a', 'b', 'c', 'a', 'b', 'b'])
print collections.Counter({'z':2, 'y':3, 'x':1})
print collections.Counter({'A':2, 'C':3, 'B':1})
print collections.Counter(d=2, e=3, f=1)
"""

import collections

print collections.Counter(['a', 'b', 'c', 'a', 'b', 'b'])
print collections.Counter({'z':2, 'y':3, 'x':1})
print collections.Counter({'A':2, 'C':3, 'B':1})
print collections.Counter(d=2, e=3, f=1)

pause()

print """
*********
cnt = collections.Counter()
print 'Initialized :', cnt

cnt.update('zyuzwoubaqrtq')
print 'As a sequence  :', cnt

cnt.update({'r':1, 'm':5})
print 'As a dictionary:', cnt
*********
"""

cnt = collections.Counter()
print 'Initialized :', cnt

cnt.update('zyuzwoubaqrtq')
print 'As a sequence  :', cnt

cnt.update({'r':1, 'm':5})
print 'As a dictionary:', cnt

pause()

print """
*********
letters = 'zdfteortypwgnlkxvciytd'
letter_set = set(letters)

cnt = collections.Counter(letters)
print "Collection: ", cnt

for letter in letter_set:
    print 'letter: %s : counter: %d' % (letter, cnt[letter])
*********
"""

letters = 'zdfteortypwgnlkxvciytd'
letter_set = set(letters)

cnt = collections.Counter(letters)
print "Collection: ", cnt

for letter in letter_set:
    print 'letter: %s : counter: %d' % (letter, cnt[letter])
    
pause()

print """
*********
cnt = collections.Counter(['a', 'b', 'c'])
print "initialized: ", cnt

print "cnt['r']: ", cnt['r']
print "after access by nonexistent key: ", cnt
*********
"""

cnt = collections.Counter(['a', 'b', 'c'])
print "initialized: ", cnt

print "cnt['r']: ", cnt['r']
print "after access by nonexistent key: ", cnt