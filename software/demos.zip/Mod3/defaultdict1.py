#################################
#
#   File:    defaultdict1.py
#
#   Description
#
#   Demonstrate collections.defaultdict
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from ver2_6 import v2_6
v2_6()

print """
*********
import collections

def default_val():
    return 'default value'

d = collections.defaultdict(default_val, lang='jython')
print 'd:', d
print 'lang =>', d['lang']
print 'jython =>', d['jython']
*********
"""

import collections
from pprint import pprint

def default_val():
    return 'default value'

d = collections.defaultdict(default_val, lang='jython')
print 'd:', d
print 'lang =>', d['lang']
print 'jython =>', d['jython']
pprint(d)
