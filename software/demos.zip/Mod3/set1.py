#################################
#
#   File:   set1.py
#
#   Description
#
#   Demonstrate set operations in slide 60 of mod 3
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
from pause import pause

try:
    S = set(range(4))
    print "S =", S
    print "0 in S =", 0 in S
    
except ValueError, e:
    print e
*********
"""

from ver2_6 import v2_6
from pause import pause

v2_6()

try:
    S = set(range(4))
    print "S =", S
    print "0 in S =", 0 in S
    
    pause()

    print """
*********
sor = S | set([3,4])
print "S =", S
print "sor =", sor
*********
    """    
    sor = S | set([3,4])
    print "S =", S
    print "sor =", sor
    
    pause() # pause
 
    print """
*********
smin = S - set([0,3])
print "S =", S
print "smin =", smin
*********
"""     
    smin = S - set([0,3])
    print "S =", S
    print "smin =", smin
    
    pause()

    print """
*********
sand = S & set([2,3])
print "S =", S
print "sand =", sand
*********
    """      
    sand = S & set([2,3])
    print "S =", S
    print "sand =", sand
    
    pause()
    
    print """
*********
sxor = S ^ set([2,3])
print "S =", S
print "sxor =", sxor
*********
    """      
    sxor = S ^ set([2,3])
    print "S =", S
    print "sxor =", sxor
    
    pause()
    
    print """
*********
sup = S > set([2,3])
print "S =", S
print "sup =", sup

sub = S < set([2,3])
print "S =", S
print "sub =", sub
*********
    """ 
    sup = S > set([2,3])
    print "S =", S
    print "sup =", sup
    print ""
    
    sub = S < set([2,3])
    print "S =", S
    print "sub =", sub
    
except ValueError, e:
    print e