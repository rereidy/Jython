
from __future__ import print_function
import sys

def enum(**enums):
    return type('Enum', (), enums)

n = enum(ONE=1, TWO=2, THREE='three')
print("{0}".format(n.ONE))

print("here", file=sys.stdout)