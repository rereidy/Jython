print """
def c2f(c):
    return c * 9/5 + 32

print c2f(100)
print c2f(0)
print c2f(30)
"""

def c2f(c):
    return c * 9/5 + 32

print c2f(100)
print c2f(0)
print c2f(30)