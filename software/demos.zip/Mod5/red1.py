#################################
#
#   File:   red1.py
#
#   Description
#
#   Demonstrate reduce()
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
r1 = reduce(lambda a, b: a * b, [1,2])
r2 = reduce(lambda a, b: a * b, [1,2,3])
r3 = reduce(lambda a, b: a * b, [1,2,3,4])

print "step 1: reduce(lambda a, b: a * b, [1,2]) =", r1, " and is a", type(r1)
print "step 2: reduce(lambda a, b: a * b, [1,2,3]) =", r2, " and is a", type(r2)
print "step 3: reduce(lambda a, b: a * b, [1,2,3,4]) =", r3, " and is a", type(r3)
*********
"""

r1 = reduce(lambda a, b: a * b, [1,2])
r2 = reduce(lambda a, b: a * b, [1,2,3])
r3 = reduce(lambda a, b: a * b, [1,2,3,4])

print "step 1: reduce(lambda a, b: a * b, [1,2]) =", r1, " and is a", type(r1)
print "step 2: reduce(lambda a, b: a * b, [1,2,3]) =", r2, " and is a", type(r2)
print "step 3: reduce(lambda a, b: a * b, [1,2,3,4]) =", r3, " and is a", type(r3)