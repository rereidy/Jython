#################################
#
#   File:   func1.py
#
#   Description
#
#   Demonstrate create and call function
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
**************
Basic function

def myfun():
    return "Returning from myfun()"
    
# call it ...
print "myfun: ", myfun()
**************
"""

from pause import pause

def myfun():
    return "Returning from myfun()"
    
# call it ...
print "myfun: ",myfun()

pause()
