#################################
#
#   File:   global1.py
#
#   Description
#
#   Demonstrate global variable use
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
i = 9    # global scope - assigned at top of module file

def f(j):        # function name "f" is also global
    i = 7        # create i in function namespace
    
    print "value of i in f() =", i
    
    k = i + j    # k and j are local names
    return k

print "call f(1) result =", f(1)
print "i =", i
*********
"""

from pause import pause

i = 9

def f(j):
    i = 7
    
    print "value of i in f() =", i
        
    k = i + j
    return k

f_res = f(1)
print "call f(1) result =", f_res
print "i =", i

pause()

print """
*********
def f1(j):
    global i        # by identifying "i" as global, it can now be modified in the function
    print "i before calculation =", i
    i += 1
    k = i + j
    return k

print "f2(1) result =", f1(1)
print "after call to f1(), i =", i
*********
"""

def f1(j):
    global i
    print "i before calculation =", i
    i += 1
    k = i + j
    return k

f1_res = f1(1)
print "f2(1) result =", f1_res
print "after call to f1(), i =", i