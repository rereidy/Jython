#################################
#
#   File:   func5.py
#
#   Description
#
#   Demonstrate argument passing symantics
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
**********
def power(x, y=2):
    r = 1
    for i in range(y):
       r = r * x
    return r

print power(3)
print power(3, 3)
print power(5, 5)
print power(x=2)
print power(4, y=2)
eval('power(x=6, 3)')    # throws an error
**********
"""

def power(x, y=2):
    r = 1
    for i in range(y):
        r = r * x
    return r

print power(3)
print power(3, 3)
print power(5, 5)
print power(x=2)
print power(4, y=2)
eval('power(x=6, 3)')