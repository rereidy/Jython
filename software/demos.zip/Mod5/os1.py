#################################
#
#   File:   os1.py
#
#   Description
#
#   Demonstrate os module
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import os

## in Jython, the OS name is "java"

print "os.name =", os.name
*********
"""

import os

from pause import pause

print "os.name =", os.name

pause()

print """
*********
import platform
import subprocess

print "Jython platform.uname() =", platform.uname()

*********
"""

import platform
import subprocess 

print "Jython platform.uname() =", platform.uname()

cmd = "python -c 'from platform import uname; print \"CPython uname =\", uname()'"
proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE,
                                         stdout=subprocess.PIPE,
                                         stderr=subprocess.PIPE, close_fds=True)
(cin, cout, cerr) = (proc.stdin, proc.stdout, proc.stderr)

# rc is the process return code
rc = proc.wait()

# trim trailing newline characters from stdout and stderr output; if either is an
# empty str type, return None
uname_out, _ = cout.read()[:-1] or None, cerr.read()[:-1] or None

print uname_out

pause()

print """
operating system (OS) name comes from java libraries

import java.lang

print "java.lang.System.getProperty('os.name') =", java.lang.System.getProperty("os.name")
"""

import java.lang

print "java.lang.System.getProperty('os.name') =", java.lang.System.getProperty("os.name")
