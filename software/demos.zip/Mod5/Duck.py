class Duck:
    def quack(self):
        print "I'm a duck - Quack, quack!"

    def fly(self):
        print "I'm a duck - Flap, Flap!"


class Person:
    def quack(self):
        print "I'm a person Quackin'!"

    def fly(self):
        print "I'm a person Flyin'!"


def in_the_forest(mallard):
    mallard.quack()
    mallard.fly()


in_the_forest(Duck())
in_the_forest(Person())