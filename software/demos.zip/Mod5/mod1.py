#################################
#
#   File:   mod1.py
#
#   Description
#
#   Demonstrate map() function
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
import sys

print "arguments:", sys.argv 
"""

import sys

print "arguments:", sys.argv
