from __future__ import with_statement

print """
*********
from __future__ import with_statement

print "Reading file using 'with' statement"
with open("/Users/rereidy/Documents/workspace/Jython/class/demos/Mod5/mod4.txt", "r") as f:
    for line in f.readlines():
        print "read line: %s" %line.rstrip("\n")

if f.closed:
    print "\nEnd of file read loop: f is closed because the 'with' statement ended; f is %s" %type(f)

*********
"""

from pause import pause

with open("/Users/rereidy/Documents/workspace/Jython/class/demos/Mod5/mod4.txt", "r") as f:
    for line in f.readlines():
        print "read line: %s" %line.rstrip("\n")

if f.closed:
    print "\nEnd of file read loop: f is closed because the 'with' statement ended; f is %s" %type(f)

pause()

print """
*********
f = open("/Users/rereidy/Documents/workspace/Jython/class/demos/Mod5/mod4.txt", "r")
for line in f.readlines():
    print "read line (no with): %s" %line.rstrip("\n")

if not f.closed:
    print "\nEnd of file read loop: f is open and is a %s" %type(f)

f.close()
*********
"""
       
f = open("/Users/rereidy/Documents/workspace/Jython/class/demos/Mod5/mod4.txt", "r")
for line in f.readlines():
    print "read line (no with): %s" %line.rstrip("\n")

if not f.closed:
    print "\nEnd of file read loop: f is open and is a %s" %type(f)

f.close()