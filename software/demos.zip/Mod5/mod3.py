print """
*********
try:
    import os
    print "module os is", type(os)

    import os.path
    print "module os.path is", type(os.path)
except:
    print "error"
*********
"""

try:
    import os
    print "module os is", type(os)

    import os.path
    print "module os.path is", type(os.path)
except:
    print "error"