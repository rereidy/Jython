#################################
#
#   File:   map1.py
#
#   Description
#
#   Demonstrate map function
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
cntr = [1,2,3,4,5]
print "cntr =", cntr, " and is a", type(cntr)

updated = []

for x in cntr:
    updated.append(x * 10)

print "cntr updated =", updated, " and is a", type(updated)
*********
"""

from pause import pause

cntr = [1,2,3,4,5]
print "cntr =", cntr, " and is a", type(cntr)

updated = []

for x in cntr:
    updated.append(x * 10)

print "cntr updated =", updated, " and is a", type(updated)

pause()

print """
*********
def incr(x): return x * 10

updated = map(incr, cntr)

print "map(incr, cntr) =", updated, " and is a ", type(updated)
*********
"""

def incr(x): return x * 10

updated = map(incr, cntr)

print "map(incr, cntr) =", updated, " and is a ", type(updated)

