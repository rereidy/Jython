#################################
#
#   File:   filt1.py
#
#   Description
#
#   Demonstrate filter()
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
r = list(range(-5, 5))
print "r =", r, " and is a", type(r)
*********
"""

from pause import pause

r = list(range(-5, 5))
print "r =", r, " and is a", type(r)

pause()

print """
*********
r1 = list(filter((lambda x: x < 0), r))    # return negative numbers
*********
"""

r1 = list(filter((lambda x: x < 0), r))

print "list(filter((lambda x: x < 0), r)) =", r1, " and is a", type(r1)
