print """
*********
class c():
    def whoami(self):
        print "whoami: class", self.__class__.__name__
        
    def f2(self):
        print self.__class__.__name__, ": f2()"
        def f2_inner():
            print self.__class__.__name__, ": f2_inner()"
        f2_inner()
        
if __name__ == "__main__":
    c().whoami()
    c().f2()
*********
"""

class c():
    def whoami(self):
        print "whoami: class", self.__class__.__name__
        
    def f2(self):
        print self.__class__.__name__, ": f2()"
        def f2_inner():
            print self.__class__.__name__, ": f2_inner()"
        f2_inner()
        
if __name__ == "__main__":
    c().whoami()
    c().f2()