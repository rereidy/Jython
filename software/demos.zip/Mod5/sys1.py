#################################
#
#   File:   sys1.py
#
#   Description
#
#   Demonstrate sys module
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
if len(sys.argv) > 0:
    for a in sys.argv:
        print "arg = ", a
*********
"""

import sys

from pause import pause

if len(sys.argv) > 0:
    for a in sys.argv:
        print "arg = ", a
        
pause()

print """
*********
print "sys.version =", sys.version
print "sys.version_info =", sys.version_info
*********
"""

print "sys.version =", sys.version
print "sys.version_info =", sys.version_info
