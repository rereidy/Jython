#################################
#
#   File:   func2.py
#
#   Description
#
#   Demonstrate polymorphism
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
def mul(x, y):
    return x * y

i = mul(3, 2)
print "mul(3, 2) =", i
print "mul(3, 2) returned a ", type(i)
*********
"""

from pause import pause

def mul(x, y):
    return x * y

i = mul(3, 2)
print "mul(3, 2) =", i
print "mul(3, 2) returned a ", type(i)

pause()

print """
float return

i = mul(3., 2)
print "mul(3., 2) =", i
print "mul(3., 2) returned a ", type(i)
"""

i = mul(3., 2)
print "mul(3., 2) =", i
print "mul(3., 2) returned a ", type(i)

pause()

print """
*********
complex return
*********
"""

i = mul(3j, 2)
print "mul(3j, 2) =", i
print "mul(3j, 2) returned a ", type(i)

pause()

print """
*********
string return

try:
    i = mul("test", "test")
    print "mul(\"test\", \"test\") =", i
    print "mul(\"test\", \"test\") is a", type(i)
except TypeError, e:
    print e

i = mul("test", 2)
print "mul(\"test\", 2) =", i
print "mul(\"test\", 2) returned a ", type(i)
*********
"""

try:
    i = mul("test", "test")
    print "mul(\"test\", \"test\") =", i
    print "mul(\"test\", \"test\") is a", type(i)
except TypeError, e:
    print e
    
pause()

i = mul("test", 2)
print "mul(\"test\", 2) =", i
print "mul(\"test\", 2) returned a ", type(i)

