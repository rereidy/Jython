#################################
#
#   File:   global2.py
#
#   Description
#
#   Demonstrate global timing
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
Y = 100

def f1():
    global Y
    Y = -1
    
def f2():
    global Y
    Y = 101

print "Y =", Y
*********
"""

from pause import pause

Y = 100

def f1():
    global Y
    Y = -1
    
def f2():
    global Y
    Y = 101
    
print "Y =", Y

pause()

print """
*********
call f1()

f1()
print "Y =", Y
*********
"""

f1()
print "Y =", Y

Y = 100

pause()

print """
*********
call f2()

f2()
print "Y =", Y

f2(); f1()
print "f2(); f1(): Y=", Y
*********
"""

f2()
print "Y =", Y

f2(); f1()
print "f2(); f1(): Y=", Y
