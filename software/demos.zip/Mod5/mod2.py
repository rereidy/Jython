print """
**********
from sys import argv

print "arguments:", argv 
**********
"""

from sys import argv

print "arguments:", argv