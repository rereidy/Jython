#################################
#
#   File:   func6.py
#
#   Description
#
#   Demonstrate more argument passing semantics
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
**********
def xsum(*args):
    r = 0
    for i in args:
        r += i
    return r

print xsum(1, 2, 3)
print xsum(1, 2, 3, 4, 5)

def display(**details):
    print "inside display() - arguments:"
    for i in details:
        print "%s: %s" % (i, details[i])

s = display(name='Larry', age=43, sex='M')
print "display(name='Larry', age=43, sex='M') = ", s, " and is a", type(s)
**********
"""

def xsum(*args):
    r = 0
    for i in args:
        r += i
    return r

i = xsum(1,2,3)
print "xsum(1, 2, 3) =", i, " and is a ", type(i)

i = xsum(1, 2, 3, 4, 5)
print "xsum(1, 2, 3, 4, 5) =", i, " and is a", type(i)

def display(**details):
    print "inside display() - arguments:"
    print "details is a", type(details)
    for i in details:
        print "%s: %s" % (i, details[i])

s = display(name='Larry', age=43, sex='M')
print "display(name='Larry', age=43, sex='M') = ", s, " and is a", type(s)
