#################################
#
#   File:   func3.py
#
#   Description
#
#   Demonstrate frop off end of function return type
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################
print """
**********
def f1():
    pass
    
ret = f1()

print type(ret)
**********
"""

def f1():
    pass
    
ret = f1()

print type(ret)