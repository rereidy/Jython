#################################
#
#   File:    script1.py
#
#   Description
#
#    Script to demonstrate first interactive Jython session
#    for Introduction to Jython.
#
#    Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

import sys
print sys.platform
print "*" * 30
x = "Test!"
print x * 10
print "*" * 30
