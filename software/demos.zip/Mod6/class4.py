#################################
#
#   File:    class4.py
#
#   Description
#
#   Demonstrate abstract class
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
class Sup:
    def dele(self):
        self.act()
        
    def act(self):
        assert False, "act() not defined in Sup"    # can also 'raise NotImplementedError("act() not defined in Sup")'
        
if __name__ == "__main__":
    try:
        x = Sup()
        x.dele()
    except AssertionError, e:
        print e
*********
"""

class Sup:
    def dele(self):
        self.act()
        
    def act(self):
        assert False, "act() not defined in Sup"
        
if __name__ == "__main__":
    try:
        x = Sup()
        x.dele()
    except AssertionError, e:
        print e