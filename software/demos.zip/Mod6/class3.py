#################################
#
#   File:    class3.py
#
#   Description
#
#   Demonstrate inheritance
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
class Sup:
    def meth(self):
        print "in Sup.meth"
        
    def dele(self):
        self.act()
        
class Inh(Sup):
    pass 

class Repl(Sup):
    def meth(self):
        print "in Repl.meth"
        
class Ext(Sup):
    def meth(self):
        print "starting Ext.meth"
        Sup.meth(self)
        print "ending Ext.meth"
        
class Prov(Sup):
    def act(self):
        print "in Prov.act"
        
if __name__ == "__main__":
    for k in (Inh, Repl, Ext):
        print "\n%s__name__ ..." %k
        k().meth()
        
    print "\nProv"
    x = Prov()
    x.dele()
*********
"""

class Sup:
    def meth(self):
        print "in Sup.meth"
        
    def dele(self):
        self.act()
        
class Inh(Sup):
    pass 

class Repl(Sup):
    def meth(self):
        print "in Repl.meth"
        
class Ext(Sup):
    def meth(self):
        print "starting Ext.meth"
        Sup.meth(self)
        print "ending Ext.meth"
        
class Prov(Sup):
    def act(self):
        print "in Prov.act"
        
if __name__ == "__main__":
    for k in (Inh, Repl, Ext):
        print "\nclass -", k.__name__, "..."
        k().meth()
        
    print "\nProv"
    x = Prov()
    x.dele()