#################################
#
#   File:    user_defined_exc2.py
#
#   Description
#
#   Demonstrate user-defined exceptions
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
class Error(Exception):
    pass

class InpErr(Error):
    def __init__(self, expr, msg):
        self.expr = expr
        self.msg = msg
        
    def __str__(self):
        return repr("Expression: '%s'; Message: '%s'" %(self.expr, self.msg))
    
class TransErr(Error):
    def __init__(self, prev, next, msg):
        self.prev = prev
        self.next = next
        self.msg  = msg
        
    def __str__(self):
        return repr("Prev: %s, Next: %s, Msg: %s" %(self.prev, self.next, self.msg))
    
try:
    print "Throwing InpErr"
    raise InpErr("1 == 2", "not equal")
except InpErr, e:
    print "InpErr has occurred -", e
    
try:
    print "Thrwoing TransErr"
    raise TransErr("one()", "three()", "Error in two()")
except TransErr, e:
    print "TransErr has occurred -", e
*********
"""

class Error(Exception):
    pass

class InpErr(Error):
    def __init__(self, expr, msg):
        self.expr = expr
        self.msg = msg
        
    def __str__(self):
        return repr("Expression: '%s'; Message: '%s'" %(self.expr, self.msg))
    
class TransErr(Error):
    def __init__(self, prev, next, msg):
        self.prev = prev
        self.next = next
        self.msg  = msg
        
    def __str__(self):
        return repr("Prev: %s, Next: %s, Msg: %s" %(self.prev, self.next, self.msg))
    
try:
    print "Throwing InpErr"
    raise InpErr("1 == 2", "not equal")
except InpErr, e:
    print "InpErr has occurred -", e
    
try:
    print "Throwing TransErr"
    raise TransErr("one()", "three()", "Error in two()")
except TransErr, e:
    print "TransErr has occurred -", e