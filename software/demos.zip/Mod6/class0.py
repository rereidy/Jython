#################################
#
#   File:    class0.py
#
#   Description
#
#   Demonstrate class calling methods
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
Create an instance of the class

class C1:                                                # class statement
    def writeln(self, msg):                              # method; "self" is the object instance
        self.msg = msg                                   # self.msg is an attribute of the instance
        print "C1: %s" %self.msg

x = C1()                                                 # create an instance of C1

x.writeln("print from an instance of C1: name is a %s" %type(x))   # execute the instance method
*********
"""

from pause import pause

class C1:
    def writeln(self, msg):
        self.msg = msg
        print "C1: %s" %self.msg

x = C1()

x.writeln("print from an instance of C1: name is a %s" %type(x))

pause()

print """
*********
Direct call to class and method

C1().writeln("direct call - no instance of C1")
*********
"""

C1().writeln("direct call - no instance of C1")