#################################
#
#   File:    user_defined_exc1.py
#
#   Description
#
#   Demonstrate user-defined exceptin
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
class MyError(Exception):
    def __init__(self, value):        # override Exception.__init__()
        self.value = value            # create attribute "value"

    def __str__(self):
        return repr(self.value)
    
try:
    print "Throwing MyError"
    raise MyError("test exception")
except MyError, e:
    print "MyError has occured -", e.value
*********
"""

class MyError(Exception):
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)
    
try:
    print "Throwing MyError"
    raise MyError("test exception")
except MyError, e:
    print "MyError has occurred -", e.value