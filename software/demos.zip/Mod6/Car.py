#################################
#
#   File:    Car.py
#
#   Description
#
#   Demonstrate class and object
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
class Car(object):   # the Car class is a subclass of "object"
    NORTH = 0        #  \
    EAST = 1         #   \
    SOUTH = 2        #   /  class variables
    WEST = 3         #  /
    
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y
        self.direction = self.NORTH
    
    def turn_right(self):
        self.direction += 1
        self.direction = self.direction % 4
        
    def turn_left(self):
        self.direction -= 1
        self.direction = self.direction % 4
        
    def move(self, distance):
        if self.direction == self.NORTH:
            self.y += distance
        elif self.direction == self.SOUTH:
            self.y -= distance
        elif self.direction == self.EAST:
            self.x += distance
        else:
            self.x -= distance
            
    def position(self):
        return (self.x, self.y)
*********
"""

from pause import pause

class Car(object):
    NORTH = 0
    EAST = 1
    SOUTH = 2
    WEST = 3
    
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y
        self.direction = self.NORTH
    
    def turn_right(self):
        print "move_right (start): %s" %(self.__str__())
        self.direction += 1
        self.direction = self.direction % 4
        print "move_right (end): %s" %(self.__str__())
        
    def turn_left(self):
        print "move_left (start): %s" %(self.__str__())
        self.direction -= 1
        self.direction = self.direction % 4
        print "move_left (end): %s" %(self.__str__())
        
    def move(self, distance):
        if self.direction == self.NORTH:
            self.y += distance
        elif self.direction == self.SOUTH:
            self.y -= distance
        elif self.direction == self.EAST:
            self.x += distance
        else:
            self.x -= distance
            
    def position(self):
        return (self.x, self.y)
    
    def __str__(self):
        return repr("direction: %d; x=%d; y=%d" %(self.direction, self.x, self.y))

def test_car():
    c = Car()
    print "afer init: ", c
    c.turn_right()
    c.move(5)
    assert (5, 0) ==  c.position()
    c.turn_left()
    c.move(3)
    assert (5, 3) == c.position()

if __name__ == "__main__":
    test_car()

    