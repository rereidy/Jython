def info(o, spacing=10, collapse=1):
    ml = [m for m in dir(o) if callable(getattr(o, m))]
    pf = collapse and (lambda s: " ".join(s.split())) or (lambda s: s)
    print "\n".join(["%s %s" %(method.ljust(spacing), pf(str(getattr(o, method).__doc__))) for method in ml])