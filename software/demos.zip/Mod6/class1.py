print """
*********
class C(object):
    def __init__(self, arg=None):    # default value is None
        self.arg = arg
            
    def __del__(self):
        print "destructor"
    
    def __str__(self):
        return repr(self.arg)
        
    def __privmeth(self):
        print "calling _privmeth()"
        
    def pubmeth(self):
        print "calling pubmeth()"
        print self.__privmeth()
    
try:
    cl = C("test")
    print "value of cl is", cl
except NameError, e:
    print e
*********
"""

from pause import pause

class C(object):
    def __init__(self, arg=None):
        self.arg = arg
        
    def __str__(self):
        return repr(self.arg)
    
    def __del__(self):
        print "destructor"
        
    def __privmeth(self):
        print "calling __privmeth()"
        
    def pubmeth(self):
        print "calling pubmeth()"
        print self.__privmeth()
    
try:
    cl = C("test")
    print "value of cl is", cl
except NameError, e:
    print e

pause()

print """
*********
Default argument
    
try:
    cl = C()        # no arg
    print "value of cl is", cl
except NameError, e:
    print e
*********
"""

try:
    cl = C()
    print "value of cl is", cl
except NameError, e:
    print e
    
pause()

print """
*********
Call private method

try:
    cl = C("attempt to call private method directly")
    print "value of cl is", cl
    cl.__privmeth()
except AttributeError, e:
    print e
*********
"""

try:
    cl = C("attempt to call private method directly")
    print "value of cl is", cl
    cl.__privmeth()
except AttributeError, e:
    print e
    
pause()

print """
*********
Call public method

try:
    cl = C("attempt to call private method directly")
    print "value of cl is", cl
    cl.pubmeth()
except AttributeError, e:
    print e
*********
"""

try:
    cl = C("calling public method")
    print "value of cl is", cl
    cl.pubmeth()
except AttributeError, e:
    print e
