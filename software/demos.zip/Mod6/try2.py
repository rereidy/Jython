#################################
#
#   File:    try2.py
#
#   Description
#
#   Demonstrate traceback module
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import sys
import traceback

def exc(recursion_level=2):
    sys.stdout.flush()
    if recursion_level:
        exc(recursion_level-1)
    else:
        raise RuntimeError()

try:
    exc()
except Exception, e:
    print "print_exxc() #1"
    traceback.print_exc(file=sys.stdout)
    print "print_exc() #2"
    traceback.print_exc(1, file=sys.stdout)
*********
"""

from pause import pause

import sys
import traceback

def exc(recursion_level=2):
    sys.stdout.flush()
    if recursion_level:
        exc(recursion_level-1)
    else:
        raise RuntimeError()

try:
    exc()
except Exception, e:
    print "print_exxc() #1"
    traceback.print_exc(file=sys.stdout)
    print "print_exc() #2"
    traceback.print_exc(1, file=sys.stdout)
    
pause()

print """
*********
try:
    exc()
except Exception, e:
    print 'print_exception():'        # print_exception == print_exc
    exc_type, exc_value, exc_tb = sys.exc_info()
    traceback.print_exception(exc_type, exc_value, exc_tb)
*********
"""

try:
    exc()
except Exception, e:
    print 'print_exception():'
    exc_type, exc_value, exc_tb = sys.exc_info()
    traceback.print_exception(exc_type, exc_value, exc_tb)

pause()

from pprint import pprint

print """
*********
try:
    exc()
except Exception, e:
    print 'print_exception():'        # print_exception == print_exc
    exc_type, exc_value, exc_tb = sys.exc_info()
    pprint(traceback.format_exception(exc_type, exc_value, exc_tb))
*********
"""

try:
    exc()
except Exception, e:
    print 'print_exception():'
    exc_type, exc_value, exc_tb = sys.exc_info()
    pprint(traceback.format_exception(exc_type, exc_value, exc_tb))
