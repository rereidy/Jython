#################################
#
#   File:    try1.py
#
#   Description
#
#   Demonstrate try/except blocks
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause

print """
*********
try:
    assert 1 ==2, "assertion demo"    # can also say 'raise AssertionError("message")'
except AssertionError, e:
    print "AssertionError: ", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
except IOError, e:
    print "IOError: ", e
except:
    print "unknown exception"
else:
    print "no exception"
finally:
    print "finally always executes"
*********
"""

try:
    assert 1 ==2, "assertion demo"
except AssertionError, e:
    print "AssertionError: ", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
except IOError, e:
    print "IOError: ", e
except:
    print "unknown exception"
else:
    print "no exception"
finally:
    print "finally always executes"

pause()

print """
*********
try:
    raise IOError("fail")
except AssertionError, e:
    print "AssertionError: ", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
except IOError, e:
    print "IOError: ", e
except:
    print "unknown exception"
else:
    print "no exception"
finally:
    print "finally always executes"
*********
"""

try:
    raise IOError("fail")
except AssertionError, e:
    print "AssertionError: ", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
except IOError, e:
    print "IOError: ", e
except:
    print "unknown exception"
else:
    print "no exception"
finally:
    print "finally always executes"

pause()

print """
*********
try:
    1 / 0
except AssertionError, e:
    print "AssertionError: ", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
except IOError, e:
    print "IOError: ", e
except:
    print "unknown exception"
else:
    print "no exception"
finally:
    print "finally always executes"
*********
"""

try:
    1 / 0
except AssertionError, e:
    print "AssertionError: ", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
except IOError, e:
    print "IOError: ", e
except:
    print "unknown exception"
else:
    print "no exception"
finally:
    print "finally always executes"
    
pause()

print """
*********
try:
    raise                    # will reraise the last exception
except AssertionError, e:
    print "AssertionError: ", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
except IOError, e:
    print "IOError: ", e
except:
    print "unknown exception"
else:
    print "no exception"
finally:
    print "finally always executes"
*********
"""

try:
    raise
except AssertionError, e:
    print "AssertionError: ", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
except IOError, e:
    print "IOError: ", e
except:
    print "unknown exception"
else:
    print "no exception"
finally:
    print "finally always executes"
    
pause()

print """
*********
import sys

try:
    sys.exc_clear()
    raise                    # will throw the generic exception
except AssertionError, e:
    print "AssertionError: ", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
except IOError, e:
    print "IOError: ", e
except:
    print "unknown exception"
else:
    print "no exception"
finally:
    print "finally always executes"
*********
"""

import sys

try:
    sys.exc_clear()
    raise
except AssertionError, e:
    print "AssertionError: ", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
except IOError, e:
    print "IOError: ", e
except:
    print "unknown exception"
else:
    print "no exception"
finally:
    print "finally always executes"
        
pause()

print """
*********
try:
    sys.exc_clear()
    raise                    # will throw the generic exception
except AssertionError, e:
    print "AssertionError: ", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
except IOError, e:
    print "IOError: ", e
except Exception, e:
    print "unknown exception: ", e
else:
    print "no exception"
finally:
    print "finally always executes"
*********
"""

try:
    sys.exc_clear()
    raise Exception('generic')
except AssertionError, e:
    print "AssertionError: ", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
except IOError, e:
    print "IOError: ", e
except Exception, e:
    print "unknown exception: ", e
else:
    print "no exception"
finally:
    print "finally always executes"
    
pause()

print """
*********
try:
    pass
except AssertionError, e:
    print "AssertionError: ", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
except IOError, e:
    print "IOError: ", e
except Exception, e:
    print "unknown exception: ", e
else:
    print "no exception"
finally:
    print "finally always executes"
*********
"""

try:
    pass
except AssertionError, e:
    print "AssertionError: ", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
except IOError, e:
    print "IOError: ", e
except Exception, e:
    print "unknown exception: ", e
else:
    print "no exception"
finally:
    print "finally always executes"