#################################
#
#   File:    class2.py
#
#   Description
#
#   Demonstrate class construcor
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
class Super:
    def __init__(self, x):
        self.x = x
        self.__writeln("Super constructor")
        
    def __writeln(self, msg):
        print msg
        
class Sub(Super):
    def __init__(self, a, b):
        self.a = a
        self.b = b
        self.__writeln("Sub constructor")
        
        Super.__init__(self, a)
        
    def __writeln(self, msg):
        print msg
        
s = Sub(range(3), "sub-class")
*********
"""

class Super:
    def __init__(self, x):
        self.x = x
        self.__writeln("Super constructor")
        
    def __writeln(self, msg):
        print msg
        
class Sub(Super):
    def __init__(self, a, b):
        self.a = a
        self.b = b
        self.__writeln("Sub constructor")
        
        Super.__init__(self, a)
        
    def __writeln(self, msg):
        print msg
        
s = Sub(range(3), "sub-class")
print s