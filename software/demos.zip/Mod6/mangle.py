#################################
#
#   File:    mangle.py
#
#   Description
#
#   Demonstrate name mangling
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

class test():
    def __init__(self):
        self.var = 1
        self._var = 2
        self.__var = 3
        
print """
Directions

1.  import the file
2.  Create an instance of the class test
3.  Examine the instance using "dir()"
"""