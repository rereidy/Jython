#################################
#
#   File:    refl1.py
#
#   Description
#
#   Demonstrate python reflection
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause

print """
*********
from apihelper import info

info("")
*********
"""

from apihelper import info

info("")

pause()

print """
*********
info(0)
*********
"""

info(0)

pause()

print """
*********
info([])
*********
"""

info([])

print """
*********
import os

info(os)
*********
"""

import os

info(os)