print """
*********
try:
    pass
except AssertionError, e:
    print "AssertError: ",e
except AttributeError, e:
    print "AttributeError:", e
except:                              # the generic handler **MUST** always be the last handler defined
    print "generic exception"
else:                                # no exception occurred
    print "else clause of exception handler"
finally:                             # block that will execute whether exception is thrown or not
    print "finally clause"
*********
"""

try:
    pass
except AssertionError, e:
    print "AssertError: ", e
except AttributeError, e:
    print "AttributeError:", e
except:
    print "generic exception"
else:
    print "else clause of exception handler"
finally:
    print "finally clause"
    
raw_input()

print """
*********
try:
    assert(1 == 2)
except AssertionError, e:
    print "AssertError: ",e
except AttributeError, e:
    print "AttributeError:", e
except:                              # the generic handler **MUST** always be the last handler defined
    print "generic exception"
else:                                # no exception occurred
    print "else clause of exception handler"
finally:                             # block that will execute whether exception is thrown or not
    print "finally clause"
*********
"""

try:
    assert(1 == 2)
except AssertionError, e:
    print "AssertError: ",e
except AttributeError, e:
    print "AttributeError:", e
except:
    print "generic exception"
else:
    print "else clause of exception handler"
finally:
    print "finally clause"
    
raw_input()

print """
*********
try:
    1/0
except AssertionError, e:
    print "AssertError: ",e
except AttributeError, e:
    print "AttributeError:", e
except:                              # the generic handler **MUST** always be the last handler defined
    print "generic exception"
else:                                # no exception occurred
    print "else clause of exception handler"
finally:                             # block that will execute whether exception is thrown or not
    print "finally clause"
*********
"""

try:
    1/0
except AssertionError, e:
    print "AssertError: ",e
except AttributeError, e:
    print "AttributeError:", e
except:
    print "generic exception"
else:
    print "else clause of exception handler"
finally:
    print "finally clause"
    
raw_input()

print """
*********
try:
    _ = 1 == 1
except AssertionError, e:
    print "AssertError: ",e
except AttributeError, e:
    print "AttributeError:", e
except:                              # the generic handler **MUST** always be the last handler defined
    print "generic exception"
else:                                # no exception occurred
    print "else clause of exception handler"
finally:                             # block that will execute whether exception is thrown or not
    print "finally clause"
*********
"""

try:
    _ = 1 == 1
except AssertionError, e:
    print "AssertError: ",e
except AttributeError, e:
    print "AttributeError:", e
except:
    print "generic exception"
else:
    print "else clause of exception handler"
finally:
    print "finally clause"

raw_input()

print """
*********
try:
    1/0
except AssertionError, e:
    print "AssertError: ",e
except AttributeError, e:
    print "AttributeError:", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
    raise
except:                              # the generic handler **MUST** always be the last handler defined
    print "generic exception"
else:                                # no exception occurred
    print "else clause of exception handler"
finally:                             # block that will execute whether exception is thrown or not
    print "finally clause"
*********
"""

try:
    1/0
except AssertionError, e:
    print "AssertError: ",e
except AttributeError, e:
    print "AttributeError:", e
except ZeroDivisionError, e:
    print "ZeroDivisionError: ", e
    raise
except:                              # the generic handler **MUST** always be the last handler defined
    print "generic exception"
else:                                # no exception occurred
    print "else clause of exception handler"
finally:                             # block that will execute whether exception is thrown or not
    print "finally clause"