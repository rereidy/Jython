#################################
#
#   File:    pdb3.py
#
#   Description
#
#   Demonstrate basic pdb post-mortem
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

def f(n):
    return n**2

class P3():
    def __init__(self, l=10):
        self.l = l
        
    def giddyup(self):
        for i in range(self.x):
            j = f(i)
            print "i = '%d'; j = '%d'" %(i, j)
            
if __name__ == "__main__":
    P3(5).giddyup()