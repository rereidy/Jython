#################################
#
#   File:    unittest5.py
#
#   Description
#
#   Demonstrate exception testing
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

import unittest

def raiseme(*args, **kwdargs):
    print args, kwdargs
    raise ValueError('unknown value: ' + str(args) + str(kwdargs))

class C5(unittest.TestCase):
    def test_localtrap(self):
        try:
            raiseme('test exception', b='some value')
        except ValueError:
            raise
        else:
            self.fail('no value error seen')
            
    def test_failunlessraises(self):
        self.failUnlessRaises(IOError, raiseme, 'force me', b=1)
        
if __name__ == "__main__":
    unittest.main()
