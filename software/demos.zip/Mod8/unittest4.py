#################################
#
#   File:    unittest4.py
#
#   Description
#
#   Demonstrate near equality assertions
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

import unittest

class C4(unittest.TestCase):
    def test_failIfAlmostEqual(self):
        self.failIfAlmostEqual(1.1, 1.11, places=3)
        
    def test_failUnlessAlmostEqual(self):
        self.failUnlessAlmostEqual(2.0101, 2.0, places=2)
        
if __name__ == "__main__":
    unittest.main()
