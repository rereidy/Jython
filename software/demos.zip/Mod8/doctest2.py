#################################
#
#   File:    doctest2.py
#
#   Description
#
#   Demonstrate doctest module with tests embedded in a text file
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################


def adder(a, b):
    return a + b

def multiplier(a, b):
    return a * b

if __name__ == "__main__":
    import doctest
    doctest.testfile('doctest2.txt')