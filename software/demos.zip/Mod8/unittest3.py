#################################
#
#   File:    unittest3.py
#
#   Description
#
#   Demonstrate equality assertions
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

import unittest

class C3(unittest.TestCase):
    def test_equal(self):
        self.failUnlessEqual(0, 1*0)
        
    def test_not_equal(self):
        self.failIfEqual(2, abs(-2))
        
if __name__ == "__main__":
    unittest.main()
