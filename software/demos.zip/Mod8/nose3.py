#################################
#
#   File:    nose3.py
#
#   Description
#
#   Demonstrate nose fixture
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from nose import with_setup

def module_su_func():
    print ""
    print "module_su_func()"
    
def module_td_func():
    print "module_td_func()"

def local_su_func():
    print "local_su_func()"

def local_td_func():
    print "local_td_func()"

def mult(a, b):
    return a*b

@with_setup(local_su_func, local_td_func)
def test_numerals():
    assert mult(3,4) == 12
 
@with_setup(local_su_func, local_td_func)   
def test_strings():
    assert mult('x', 4) == 'yyyy'

class N3:
    @classmethod
    def setup_cls(cls):
        print "N3.setup_cls()"
        
    @classmethod
    def teardown_cls(cls):
        print "N3.teardown_cls()"
        
    def test_numeral(self):
        print "test_numerals: 10,10"
        assert mult(10, 10) == 100
    
    def test_string(self):
        print "test_string: x, 2"
        assert mult('x', 2) == 'xx'
    
    def setup(self):
        print "N3.setup()"

    def teardown(self):
        print "N3.teardown()"

def mult(a, b):
    return a*b
