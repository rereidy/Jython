#################################
#
#   File:    nose1.py
#
#   Description
#
#   Demonstrate basic nose test
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

def mult(a, b):
    return a*b

def test_numerals():
    assert mult(3,4) == 12
    
def test_strings():
    assert mult('x', 4) == 'yyyy'