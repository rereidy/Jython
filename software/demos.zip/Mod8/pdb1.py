#################################
#
#   File:    pdb1.py
#
#   Description
#
#   Demonstrate basic pdb actions
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

def f(n):
    return n**2

class P1():
    def __init__(self, l=10):
        self.l = l
        
    def giddyup(self):
        for i in range(self.l):
            j = f(i)
            print "i = '%d'; j = '%d'" %(i, j)
            
if __name__ == "__main__":
    P1(5).giddyup()