#################################
#
#   File:    unittest1.py
#
#   Description
#
#   Demonstrate basic unittest module
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

import unittest

class C1(unittest.TestCase):
    def test(self):
        self.failUnless(1 == 2, "not true")
        
if __name__ == "__main__":
    unittest.main()
