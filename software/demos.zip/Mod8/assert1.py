#################################
#
#   File:    assert1.py
#
#   Description
#
#   Demonstrate use of assert statement
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
x = 1
try:
    assert x == 1, "x != 1"
    assert x > 0, "x !> 0"
    assert x == 2, "x != 2"
except AssertionError, e:
    print "Exception: ", e
*********
"""

from pause import pause

x = 1
try:
    assert x == 1, "x != 1"
    assert x > 0, "x !> 0"
    assert x == 2, "x != 2"
except AssertionError, e:
    print "Exception: ", e
    
pause()

