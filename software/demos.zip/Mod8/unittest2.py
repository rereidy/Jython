#################################
#
#   File:    unittest2.py
#
#   Description
#
#   Demonstrate truth assertions
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

import unittest

class C2(unittest.TestCase):
    def test_failUnless(self):
        self.failUnless(True)
        
    def test_assrtTrue(self):
        self.assertTrue(True)
        
    def test_failIf(self):
        self.failIf(False)
        
    def tst_assertFalse(self):
        self.assertFalse(False)
        
if __name__ == "__main__":
    unittest.main()
