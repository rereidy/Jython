#################################
#
#   File:    unittest6.py
#
#   Description
#
#   Demonstrate setUp() and tearDown()
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

import unittest

class C6(unittest.TestCase):
    def setUp(self):
        print "set up"
        self.fixture = range(-1,10)
        
    def tearDown(self):
        print "tear down"
        del self.fixture
        
    def test(self):
        print "testing"
        self.failUnlessEqual(self.fixture, range(1, 10))

if __name__ == "__main__":
    unittest.main()
