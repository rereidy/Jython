#################################
#
#   File:    unittest7.py
#
#   Description
#
#   Demonstrate doctest and unittest together
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

import unittest
import doctest
import doctest1

test_suite = unittest.TestSuite()
test_suite.addTest(doctest.DocTestSuite(doctest1))
test_suite.addTest(doctest.DocFileSuite('doctest2.txt'))

runner = unittest.TextTestRunner(verbosity=2)
runner.run(test_suite)
