#################################
#
#   File:    person.py
#
#   Description
#
#   Demonstrate development uint testing technique
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

class P:
    def __init__(self, d1, d2=None, x=0):
        self.d1 = d1
        self.d2 = d2
        self.x = x
        
    def __str__(self):
        return repr("d1 = '%s'; d2 = '%s'; x = '%d'" %(self.d1, self.d2, self.x))

if __name__ == "__main__":
    a = P('one')
    print "a: ", a
    b = P('two', 'Ron')
    print "b: ", b