#################################
#
#   File:    nose2.py
#
#   Description
#
#   Demonstrate nose fixture
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from nose import with_setup

def local_su_func():
    pass

def local_td_func():
    pass

def mult(a, b):
    return a*b

@with_setup(local_su_func, local_td_func)
def test_numerals():
    assert mult(3,5) == 12