#################################
#
#   File:    unittest8.py
#
#   Description
#
#   Demonstrate unittest a Java class
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

import unittest
import java

class C8(unittest.TestCase):
    def test_Jyth_bool_true(self):
        self.assertTrue(True, "assertTrue(True) failure")

    def test_Jyth_bool_false(self):
        self.assertTrue(False, "assertTrue(False) failure")
        
    def test_JavaBool_0(self):
        self.assertTrue(java.lang.Boolean(0), "assertTrue(java.lang.Boolean(0)) failure")

    def test_JavaBool_1(self):
        self.assertTrue(java.lang.Boolean(1), "assertTrue(java.lang.Boolean(1)) failure")
        
    def test_fileunlessequal_JythString_JavaString(self):
        jyths = "Test"
        javas = java.lang.String("Test")
        self.failUnlessEqual(jyths, javas, "Jython %s != Java %s" %(jyths, javas))

    def test_failunlessequal_JythInt_JavaInt(self):
        jythi = 1
        javai = java.lang.Integer(1)
        self.failUnlessEqual(jythi, javai, "Jython int %d != java.lang.Integer(1)" %(jythi))

    def test_failunlessequal_JythInt_JavaInt_coerced(self):
        jythi = 1
        javai = int(str(java.lang.Integer(1)))  # coerce java.lang.Integer to a Jython string, and then to a Jython int
        self.failUnlessEqual(jythi, javai, "Jython int %d != int(java.lang.Integer(1))" %(jythi))

if __name__ == "__main__":
    unittest.main()
