#################################
#
#   File:    doctest1.py
#
#   Description
#
#   Demonstrate doctest module
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################


def adder(a, b):
    """
    >>> adder(2, 6)
    8
    
    >>> adder('x', 3)
    'xxx' 
    """
    return a + b

def multiplier(a, b):
    """
    >>> multiplier(2, 6)
    12
    
    >>> multiplier('x', 3)
    'xxx'
    """
    return a * b

if __name__ == "__main__":
    import doctest
    doctest.testmod()