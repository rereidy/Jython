#################################
#
#   File:    doctest4.py
#
#   Description
#
#   Demonstrate doctest traceback
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

def raiseme():
    """
    >>> raiseme()
    Traceback (most recent call last):
      File "<stdin>", line 1, in <module>
      File "<stdin>", line 2, in raiseme
    RuntimeError: test error

    >>> raiseme()
    Traceback (most recent call last):
    RuntimeError: test error
    """
    raise RuntimeError("test error")

if __name__ == "__main__":
    import doctest
    doctest.testmod()