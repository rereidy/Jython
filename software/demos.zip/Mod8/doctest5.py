#################################
#
#   File:    doctest5.py
#
#   Description
#
#   Demonstrate _test__ module level variable
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

__test__ = {
    'number': """
>>> func(2, 3)
6

>>> func(2.0, 3)
6.0
""",
    'string': """
>>> func('x', 4)
'xxxx'

>>> func(4, 'b')
'bbbb'
""",
    'external':"doctest5",
            }

def func(a, b):
    """
    >>> func('z', 'z')
    'z'

    >>> func('z', 'z')
    Traceback (most recent call last):
    TypeError: can't multiply sequence by non-int of type 'str'
    """
    return a*b

if __name__ == "__main__":
    import doctest
    doctest.testmod()