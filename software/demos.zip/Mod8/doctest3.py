#################################
#
#   File:
#
#   Description
#
#   Demonstrate
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

class MT(object):
    pass

def fuzzy(obj):
    """
    >>> fuzzy(MT())
    [<doctest.MT object at 0x2>]
    
    >>> fuzzy(MT()) #doctest: +ELLIPSIS
    [<doctest3.MT object at 0x...>]
    """
    return [obj]