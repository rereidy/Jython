#################################
#
#   File:    shutils1.py
#
#   Description
#
#   Demonstrate shutil module
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause

import shutil
import glob
from os import environ

print """
*********
import shutil
import glob
from os import environ

files = glob.glob("%s/Mod10/file.*" %environ['DEMOS'])
print "START:", files
shutil.copyfile(files[0], "%s.copy" %files[0])
print "AFTER:", glob.glob("%s/Mod10/file.*" %environ['DEMOS'])
*********
"""

files = glob.glob("%s/Mod9/file.*" %environ['DEMOS'])
print "START:", files
shutil.copyfile(files[0], "%s.copy" %files[0])
print "AFTER:", glob.glob("%s/Mod10/file.*" %environ['DEMOS'])

pause()
