#################################
#
#   File:    que2.py
#
#   Description
#
#   Demonstrate queues LIFO and Priority
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause

from ver2_6 import v2_6

v2_6()

print """
*********
import Queue

q = Queue.LifoQueue()

for i in range(5):
    q.put(i)
    
print "queue size: ",q.qsize()

while not q.empty():
    print q.get()
*********
"""

import Queue

q = Queue.LifoQueue()

for i in range(5):
    q.put(i)
    
print "queue size: ",q.qsize()

while not q.empty():
    print q.get()
    
pause()

print """
*********
class proc(object):
    def __init__(self, priority, desc):
        self.priority = priority
        self.desc = desc
        
        print "process added: '%s'; priority: %d" %(self.desc, self.priority)
        
    def __cmp__(self, otherone):
        return cmp(self.priority, otherone.priority)

q = Queue.PriorityQueue()

q.put(proc(10, 'Low level process'))
q.put(proc(0, 'Very important process'))
q.put(proc(1, 'Important process'))

while not q.empty():
    next_proc = q.get()
    print "Proc (priority %d):" %next_proc.priority, next_proc.desc 
*********
"""

pause()

class proc(object):
    def __init__(self, priority, desc):
        self.priority = priority
        self.desc = desc
        
        print "process added: '%s'; priority: %d" %(self.desc, self.priority)
        
    def __cmp__(self, otherone):
        return cmp(self.priority, otherone.priority)

q = Queue.PriorityQueue()

q.put(proc(10, 'Low level process'))
q.put(proc(0, 'Very important process'))
q.put(proc(1, 'Important process'))

while not q.empty():
    next_proc = q.get()
    print "Proc (priority %d):" %next_proc.priority, next_proc.desc 