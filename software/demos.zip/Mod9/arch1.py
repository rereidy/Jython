#################################
#
#   File:
#
#   Description
#
#   Demonstrate
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import tarfile
import glob
from os import getenv
from os.path import exists
import sys

try:
    dest = getenv('DEMO')
    
    if dest is None:
        raise ValueError("DEMOS not in environment")
    
    pyfiles = glob.glob("%s/Mod10/*.py" %dest)
    if len(pyfiles):
        tfile = tarfile.open("/tmp/pyarch.tar", bufsize=4096)
        for fname in pyfiles:
            if exists(fname):
                tfile.add(fname)
                print "added: %s" %tfile
            else:
                print >> sys.stderr, "file not found: %s" %fname
        tfile.close()
        tar_files = glob.glob("/tmp/pyarch.tar")
        if len(tar_files):
            print "tar file:", "\n".join(tar_files)
        else:
            raise IOError("cannot find: 'tmp/pyarch.tar'")
    else:
        raise ValueError("no python files found") 
except (ValueError, IOError), e:
    print e
    sys.exit(1)
else:
    sys.exit(0)
*********
"""

import tarfile
import glob
import os
from os.path import exists
import sys

try:
    dest = os.getenv('DEMOS')
    
    if dest is None:
        raise ValueError("DEMOS not in environment")
    
    pyfiles = glob.glob("%s/Mod10/*.py" %dest)
    if len(pyfiles):
        tfile = tarfile.open("/tmp/pyarch.tar", bufsize=4096, mode="w")
        for fname in pyfiles:
            if exists(fname):
                tfile.add(fname)
                print "added: %s" %fname
            else:
                print >> sys.stderr, "file not found: %s" %fname
        tfile.close()
        tar_files = glob.glob("/tmp/pyarch.tar")
        if len(tar_files):
            for f in tar_files:
                sz = os.stat(f).st_size
                print "tar file: %s; size: %d" %(f, sz)
        else:
            raise IOError("cannot find: 'tmp/pyarch.tar'")
    else:
        raise ValueError("no python files found") 
except (ValueError, IOError), e:
    print e
    sys.exit(1)
else:
    sys.exit(0)