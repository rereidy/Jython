#################################
#
#   File:    thread1.py
#
#   Description
#
#   Demonstrate basic threading
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause

import threading

print """
*********
import threading

def worker():
    print 'Worker'
    return

threads = []
for i in range(5):
    t = threading.Thread(target=worker)
    threads.append(t)
    t.start()
*********
"""

def worker():
    print 'Worker'
    return

threads = []
for i in range(5):
    t = threading.Thread(target=worker)
    threads.append(t)
    t.start()
    
pause()

print """
*********
def worker1(num):
    print 'Worker: %s' %num
    return

threads = []
for i in range(5):
    t = threading.Thread(target=worker, args=(1,))
    threads.append(t)
    t.start()
*********
"""

def worker1(num):
    print 'Worker: %s' %num
    return

threads = []
for i in range(5):
    t = threading.Thread(target=worker1, args=(i,))
    threads.append(t)
    t.start()