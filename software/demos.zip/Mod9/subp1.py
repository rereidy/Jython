#################################
#
#   File:    subp1.py
#
#   Description
#
#   Demonstrate
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause

print """
*********
import subprocess

try:
    rc = subprocess.call(["ls", "-la"])
    print "subprocess.call(['ls', '-la']):", rc
    rc = subprocess.call(["xx"])x
    print "subprocess.call(['xx']):", rc
except OSError, e:
    print e
*********
"""

import subprocess

try:
    rc = subprocess.call(["ls", "-la"])
    print "subprocess.call(['ls', '-la']):", rc
    rc = subprocess.call(["xx"])
    print "subprocess.call(['xx']):", rc
except OSError, e:
    print e
    
pause()

print """
*********
print "subprocess.check_output(['echo', 'test']): %r" %(subprocess.check_output(['echo', 'test']))
*********
"""

print "subprocess.check_output(['echo', 'test']): %r" %(subprocess.check_output(['echo', 'test']))
