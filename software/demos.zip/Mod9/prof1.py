#################################
#
#   File:   prof1.py
#
#   Description
#
#   Demonstrate
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause
import sys

print """
*********
import profile

def fib(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib(n-1) + fib(n-2)

def fib_seq(n):
    seq = []
    if n > 0:
        seq.extend(fib_seq(n-1))
    seq.append(fib(n))
    return seq

print 'RAW\n%s' %('=' * 80)
profile.run('print fib_seq(n); print')
*********
"""

pause()

import profile

def fib(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib(n-1) + fib(n-2)

def fib_seq(n):
    seq = []
    if n > 0:
        seq.extend(fib_seq(n-1))
    seq.append(fib(n))
    return seq

class memoize:
    # from http://avinashv.net/2008/04/python-decorators-syntactic-sugar/
    def __init__(self, function):
        self.function = function
        self.memoized = {}

    def __call__(self, *args):
        try:
            return self.memoized[args]
        except KeyError:
            self.memoized[args] = self.function(*args)
            return self.memoized[args]

@memoize
def bif(n):
    # from http://en.literateprograms.org/Fibonacci_numbers_(Python)
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return bif(n-1) + bif(n-2)

def bif_seq(n):
    seq = []
    if n > 0:
        seq.extend(bif_seq(n-1))
    seq.append(bif(n))
    return seq

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print "usage: %s int" %sys.argv[0]
        sys.exit(1)

    n = int(sys.argv[1])

    print 'RAW\n%s' %('=' * 80)
    profile.run('print fib_seq(n); print')

    pause()
    print 'MEMOIZED'
    print '=' * 80
    profile.run('print bif_seq(n); print')