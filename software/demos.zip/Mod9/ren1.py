#################################
#
#   File:    ren_del.py
#
#   Description
#
#   Demonstrate os.rename() function
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import os
import glob

files = glob.glob("%s/Mod10/file1.*" %os.environ['DEMOS'])
print "BEFORE:", files
oldfname = files[0]
newfname = "%s.ren" %files[0]

os.rename(files[0], newfname)
print "AFTER:", glob.glob("%s/Mod10/file1.*" %os.environ['DEMOS'])

dirlist = os.listdir("%s/Mod10" %os.environ['DEMOS'])

print "current contents of %s/Mod10 after rename():" %os.environ['DEMOS']
print "\n".join(dirlist)

os.rename(newfname, oldfname)
*********
"""
from pause import pause

import os
import glob

files = glob.glob("%s/Mod10/file1.*" %os.environ['DEMOS'])
print "BEFORE:", files
oldfname = files[0]
newfname = "%s.ren" %files[0]

os.rename(files[0], newfname)
print "AFTER:", glob.glob("%s/Mod10/file1.*" %os.environ['DEMOS'])

dirlist = os.listdir("%s/Mod10" %os.environ['DEMOS'])

print "current contents of %s/Mod10 after rename():" %os.environ['DEMOS']
print "\n".join(dirlist)

pause()

os.rename(newfname, oldfname)