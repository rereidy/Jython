#################################
#
#   File:    rem1.py
#
#   Description
#
#   Demonstrate os.remove()
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

import os
from shutil import copyfile
import glob

print """
*********
import os
from shutil import copyfile
import glob

directory = "%s/Mod10" %os.environ['DEMOS']
if not os.path.exists("%s/del.txt" %directory):
    copyfile("%s/Copy_of_del.txt" %directory, "%s/del.txt" %directory)
    
dfname = glob.glob("%s/*del.txt" %directory)
print "BEFORE:", dfname
if os.path.exists("%s/del.txt" %directory):
    print "deleting del.txt"
    os.remove("%s/del.txt" %directory)
    print "AFTER:", glob.glob("%s/*del.txt" %directory)
else:
    print "file not found: %s/del.txt" %directory
*********
"""

from pause import pause

pause()

directory = "%s/Mod10" %os.environ['DEMOS']
if not os.path.exists("%s/del.txt" %directory):
    copyfile("%s/Copy_of_del.txt" %directory, "%s/del.txt" %directory)
    
dfname = glob.glob("%s/*del.txt" %directory)
print "BEFORE:", dfname
if os.path.exists("%s/del.txt" %directory):
    print "deleting del.txt"
    os.remove("%s/del.txt" %directory)
    print "AFTER:", glob.glob("%s/*del.txt" %directory)
else:
    print "file not found: %s/del.txt" %directory
