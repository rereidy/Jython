#################################
#
#   File:    que1.py
#
#   Description
#
#   Demonstrate FIFO queue
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import Queue

# FIFO queue

q = Queue.Queue()

for i in range(5):
    q.put(i)

print "queue size: ",q.qsize()

while not q.empty():
    print q.get()
*********
"""

import Queue

q = Queue.Queue()

for i in range(5):
    q.put(i)

print "queue size: ",q.qsize()

while not q.empty():
    print q.get()
