#################################
#
#   File:    lookb.py
#
#   Description
#
#   Demonstrate look behind
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause

print """
*********
Positive:

import re

patt = re.compile(r'(?<=George\s)Washington')
s = "Presidents: George Washington and George Bush"
m = patt.finditer(s)
for res in m:
    print "start: %d; end: %d" %(res.start(), res.end())
*********
"""

import re

patt = re.compile(r'(?<=George\s)Washington')
s = "Presidents: George Washington and George Bush"
m = patt.finditer(s)
for res in m:
    print "start: %d; end: %d" %(res.start(), res.end())

pause()

print """
*********
Negative:

import re

patt = re.compile(r'(?<!John\s)Washington')
s = "Presidents: George Washington and George Bush"
m = patt.finditer(s)
for res in m:
    print "start: %d; end: %d" %(res.start(), res.end())
***
"""

patt = re.compile(r'(?<!John\s)Washington')
s = "Presidents: George Washington and George Bush"
m = patt.finditer(s)
for res in m:
    print "start: %d; end: %d" %(res.start(), res.end())