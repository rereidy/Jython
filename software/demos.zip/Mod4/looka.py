#################################
#
#   File:    looka.py
#
#   Description
#
#   Demonstrate look ahead
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause

print """
*********
Positive:

import re

patt = re.compile(r'(?=fox)')    # positive look ahead
s = "The quick brown fox jumped over the lazy dog."
m = patt.search(s)
print "searching '%s'\nmatch.start = %d, match.end() = %d, match.group(): " %(s, m.start(), m.end()), m.group()
*********
"""

from pause import pause

import re

patt = re.compile(r'(?=fox)')
s = "The quick brown fox jumped over the lazy dog."
m = patt.search(s)
print "searching '%s'\nmatch.start = %d, match.end() = %d, match.group(): " %(s, m.start(), m.end()), m.group()

pause()

print """
*********
Positive:
patt = re.compile(r'\w+(?=,)')
s = "The golf foresome: Ron, Fred, Dan, and Alex."
m = patt.findall(s)
print "searching '%s'\nmatched: " %s, m
*********
"""

patt = re.compile(r'\w+(?=,)')
s = "The golf foresome: Ron, Fred, Dan, and Alex."
m = patt.findall(s)
print "searching '%s'\nmatched: " %s, m

pause()

print """
*********
Positive:

patt = re.compile(r'\w+,')
s = "The golf foresome: Ron, Fred, Dan, and Alex."
m = patt.findall(s)
print "searching '%s'\nmatched: " %s, m
*********
"""

patt = re.compile(r'\w+,')
s = "The golf foresome: Ron, Fred, Dan, and Alex."
m = patt.findall(s)
print "searching '%s'\nmatched: " %s, m

pause()

print """
*********
Positive:
patt = re.compile(r'\w+(?=,|\.)')
s = "The golf foresome: Ron, Fred, Dan, and Alex."
m = patt.findall(s)
print "searching '%s'\nmatched: " %s, m
*********
"""

patt = re.compile(r'\w+(?=,|\.)')
s = "The golf foresome: Ron, Fred, Dan, and Alex."
m = patt.findall(s)
print "searching '%s'\nmatched: " %s, m

pause()

print """
*********
Negative:
patt = re.compile(r'George(?!\sSmith)')
s = "Presidents: George Washington and George Bush"
m = patt.finditer(s)
for res in m:
    print "start: %d; end: %d" %(res.start(), res.end())
*********
"""

patt = re.compile(r'George(?!\sSmith)')
s = "Presidents: George Washington and George Bush"
m = patt.finditer(s)
for res in m:
    print "start: %d; end: %d" %(res.start(), res.end())

