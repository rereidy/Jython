#################################
#
#   File:    grp1.py
#
#   Description
#
#   Demonstrate group()
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import re

try:
    patt = re.compile(r"(\w+) (\w+)")
    m = patt.search("Hello world")
    print "match.group(): ", m.group()      # entire match
    print "match.group(0): ", m.group(0)    # entire match
    print "match.group(1): ", m.group(1)    # 1st group
    print "match.group(2): ", m.group(2)    # 2nd group
    print "match.group(3): ", m.group(3)    # throws exception - no index of 3
except IndexError, e:
    print "Exception:", e

print "match.group(0, 2): ", m.group(0, 2)  # entire group and 2nd group 
*********
"""

from pause import pause

import re

try:
    patt = re.compile(r"(\w+) (\w+)")
    m = patt.search("Hello world")
    print "match.group(): ", m.group()
    print "match.group(0): ", m.group(0)
    print "match.group(1): ", m.group(1)
    print "match.group(2): ", m.group(2)
    print "match.group(3): ", m.group(3)
except IndexError, e:
    print "Exception:", e

print "match.group(0, 2): ", m.group(0, 2), " and is a", type(m.group(0, 2))

pause()

print """
*********
try:
    patt = re.compile(r"(?P<first>\w+) (?P<second>\w+)")
    m = patt.search("Hello world")
    print "match.group('first'): ", m.group('first'), " and is a", type(m.group('first'))
    print "match.group('second'): ", m.group('second'), " and is a", type(m.group('second'))
    print "match.group('third'): ", m.group('third'), " and is a", type(m.group('third'))
except IndexError, e:
    print "Exception:", e

print "match.group('first', 'second'): ", m.group('first', 'second'), " and is a", type(m.group('first', 'second'))
*********
"""

try:
    patt = re.compile(r"(?P<first>\w+) (?P<second>\w+)")
    m = patt.search("Hello world")
    print "match.group('first'): ", m.group('first'), " and is a", type(m.group('first'))
    print "match.group('second'): ", m.group('second'), " and is a", type(m.group('second'))
    print "match.group('third'): ", m.group('third'), " and is a", type(m.group('third'))
except IndexError, e:
    print "Exception:", e
    
print "match.group('first', 'second'): ", m.group('first', 'second'), " and is a", type(m.group('first', 'second'))

pause()

print """
*********
try:
    patt = re.compile(r"(\w+) (\w+)")
    m = patt.search("Hola mundo")
    print "match.groups(): ", m.groups(), " and is a", type(m.groups())
    m = patt.search("Hola ")
    print "match.groups('world'): ", m.groups("world"), " and is a", type(m.groups("world"))
except (IndexError, AttributeError), e:
    print "Exception:", e
*********
"""

try:
    patt = re.compile(r"(\w+) (\w+)")
    m = patt.search("Hola mundo")
    print "match.groups(): ", m.groups(), " and is a", type(m.groups())
    m = patt.search("Hola ")
    print "match.groups('world'): ", m.groups("world"), " and is a", type(m.groups("world"))
except (IndexError, AttributeError), e:
    print "Exception:", e
    
pause()

print """
*********
try:
    patt = re.compile(r"(?P<first>\w+) (?P<second>\w+)")
    m = patt.search("Hello world")
    m_dict = m.groupdict()
    print "match.groupdict(): ", m_dict, " and is a", type(m_dict)
except IndexError, e:
    print "Exception:", e
*********
"""

try:
    patt = re.compile(r"(?P<first>\w+) (?P<second>\w+)")
    m = patt.search("Hello world")
    m_dict = m.groupdict()
    print "match.groupdict(): ", m_dict, " and is a", type(m_dict)
except IndexError, e:
    print "Exception:", e
