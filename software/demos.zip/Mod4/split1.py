#################################
#
#   File:    split1.py
#
#   Description
#
#   Demonstrate re.split()
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import re

s = re.split( r"\n", "Beautiful is better than ugly.\nExplicit is better than implicit.")
print "re.split( r'\\n', 'Beautiful is better than ugly.\\nExplicit is better than implicit.')\n", s, " and is a", type(s)

*********
"""

from pause import pause

import re

s = re.split( r"\n", "Beautiful is better than ugly.\nExplicit is better than implicit.")
print "re.split( r'\\n', 'Beautiful is better than ugly.\\nExplicit is better than implicit.')\n", s, " and is a", type(s)

pause()

print """
*********
patt = re.compile(r'\W')
s2 = patt.split("hello    world")
print 'patt.split("hello    world"): ', s2, ' and is a', type(s2)
*********
"""

patt = re.compile(r'\W')
s2 = patt.split("hello    world")
print 'patt.split("hello    world"): ', s2, ' and is a', type(s2)
