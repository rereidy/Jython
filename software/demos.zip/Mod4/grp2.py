#################################
#
#   File:
#
#   Description
#
#   Demonstrate
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import re 

patt = re.compile(r'Ital(i|o)an')
m = patt.search('Italian')
print "match.groups(): ", m.groups()    # group captured
*********
"""

from pause import pause

import re 

patt = re.compile(r'Ital(i|o)an')
m = patt.search('Italian')
print "match.groups(): ", m.groups()

pause()

print """
*********
patt = re.compile(r'Ital(?:i|o)an')
m = patt.search('Italian')
print "match.groups(): ", m.groups()    # not captured; group cannot be referenced
*****
"""

patt = re.compile(r'Ital(?:i|o)an')
m = patt.search('Italian')
print "match.groups(): ", m.groups()