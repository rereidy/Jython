#################################
#
#   File:
#
#   Description
#
#   Demonstrate
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import re

patt = re.compile(r'(\w+) \1')
m = patt.findall(r'hello hello world world xy xy')
for line in m:
    print "duplicate word: ", line
*********
"""

from pause import pause

import re

patt = re.compile(r'(\w+) \1')
m = patt.findall(r'hello hello world world xy xy')
for line in m:
    print "duplicate word: ", line

pause()

print """
*********
Substitution by group number:

patt = re.compile(r"(\d+)-(\w+)")
s = patt.sub(r"\2-\1", "1-one\t2-two\t3-three")
print "sub(r'\\2-\\1', '1-one\\t2-two\\t3-three') =", s
*********
"""

patt = re.compile(r"(\d+)-(\w+)")
s = patt.sub(r"\2-\1", "1-one\t2-two\t3-three")
print "sub(r'\\2-\\1', '1-one\\t2-two\\t3-three') =", s

pause()

print """
*********
Substitution by group names:

patt = re.compile(r"(?P<num>\d+)-(?P<word>\w+)")
s = patt.sub(r"\g<word>-\g<num>", "9-nine\t8-eight\t7-seven")
print "sub(r'\\2-\\1', '9-nine\\t8-eight\\t7-seven') =", s
*********
"""

patt = re.compile(r"(?P<num>\d+)-(?P<word>\w+)")
s = patt.sub(r"\g<word>-\g<num>", "9-nine\t8-eight\t7-seven")
print "sub(r'\\2-\\1', '9-nine\\t8-eight\\t7-seven') =", s