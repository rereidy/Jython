#################################
#
#   File:   regex1.py
#
#   Description
#
#   Demonstrate basic rexex use
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
s = "I play golf each weekend"
print "golf is in '%s' - %s" %(s, "golf" in s)
*********
"""

from pause import pause

s = "I play golf each weekend"
print "golf is in '%s' - %s" %(s, "golf" in s)

pause()

print """
*********
import re

srch = re.search("golf", "I play golf each weekend")
print "srch is a", type(srch)
print srch
*********
"""

import re

srch = re.search("golf", "I play golf each weekend")
print "srch is a", type(srch)
print srch

pause()

print """
*********
srch is a match object (see above)

print "srch results: ", srch.group()
*********
"""

print "srch results: ", srch.group()

pause()

print """
*********
try:
    srch = re.search("xx", "I play golf each weekend")
    print "srch is a", type(srch)
    print srch
    print "srch results: ", srch.groups()
except AttributeError, e:
    print "Exception:", e
*********
"""

try:
    srch = re.search("xx", "I play golf each weekend")
    print "srch is a", type(srch)
    print srch
    print "srch results: ", srch.groups()
except AttributeError, e:
    print "Exception:", e