#################################
#
#   File:    sub1.py
#
#   Description
#
#   Demonstrate re.sub()
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import re

patt = re.compile(r"[0-9]+")
s = patt.sub("$", "order0    order1    order99")
print 'sub("$", "order0    order1    order99"): ', s, " and is a", type(s)
*********
"""

from pause import pause

import re

patt = re.compile(r"[0-9]+")
s = patt.sub("$", "order0    order1    order99")
print 'sub("$", "order0    order1    order99"): ', s, " and is a", type(s)

pause()

print """
*********
s = patt.sub("-", "order0    order1    order99", 2)
print 'sub("-", "order0    order1    order99", 2): ', s, " and is a", type(s)
*********
"""

s = patt.sub("-", "order0    order1    order99", 2)
print 'sub("-", "order0    order1    order99", 2): ', s, " and is a", type(s)

pause()

print """
*********
s = patt.subn("^^", "invoice1    invoice2    invoice99")
print 'subn("^^", "invoice1    invoice2    invoice99"): ', s, " and is a", type(s)
*********
"""

s = patt.subn("^^", "invoice1    invoice2    invoice99")
print 'subn("^^", "invoice1    invoice2    invoice99"): ', s, " and is a", type(s)

pause()

print """
*********
s = patt.subn("^^", "invoice1    invoice2    invoice99", 2)
print 'subn("^^", "invoice1    invoice2    invoice99", 2): ', s, " and is a", type(s)
*********
"""

s = patt.subn("^^", "invoice1    invoice2    invoice99", 2)
print 'subn("^^", "invoice1    invoice2    invoice99", 2): ', s, " and is a", type(s)
