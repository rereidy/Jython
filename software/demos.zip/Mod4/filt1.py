from __future__ import with_statement

#################################
#
#   File:    filt1.py
#
#   Description
#
#   Demonstrate regex file filtering
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
from __future__ import with_statement
import re

regex_pattern = r"(\b\w{15}\b)"
patt = re.compile(regex_pattern)

lines_read, lines_matched = 0, 0
with open("/Users/rereidy/Documents/workspace/Jython/class/demos/Mod2/doi.txt", 'r') as f:
    print "filtering file: %s\n" %f.name
    for line in f.readlines():
        lines_read += 1
        words = patt.findall(line)
        if len(words):
            print "pattern ('%s') found in line number %d: " %(regex_pattern, lines_read), words
            lines_matched += 1
            
print "\nLines read: %d; lines matched: %d" %(lines_read, lines_matched)
*********
"""

import re

regex_pattern = r"(\b\w{10}\b)"
patt = re.compile(regex_pattern)

lines_read, lines_matched = 0, 0
with open("/Users/rereidy/Documents/workspace/Jython/class/demos/Mod2/doi.txt", 'r') as f:
    print "filtering file: %s\n" %f.name
    for line in f.readlines():
        lines_read += 1
        words = patt.findall(line)
        if len(words):
            print "pattern ('%s') found %d word(s) in line number %d: %s" %(regex_pattern, len(words), lines_read, ', '.join(words))
            lines_matched += 1
            
print "\nLines read: %d; lines matched: %d" %(lines_read, lines_matched)
