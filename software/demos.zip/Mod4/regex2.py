print """
*********
import re

pat = re.compile("abcd")
print "pat is a", type(pat)
*********
"""

import re
from pause import pause

pat = re.compile("abcd")
print "pat is a", type(pat)

pause()

print """
*********
s = "ABCDEabcd"
mtch = pat.search(str)
print "mtch is a", mtch
*********
"""

s = "ABCDEabcd"
mtch = pat.search(s)
print "mtch is a", mtch

pause()

print """
*********
print "number of groups matched =", len(mtch.group())

if mtch:
    print "matched: ", mtch.group()
    for g in mtch.group():
        print "matched group is %s - value is '%s'" %(type(g), g)
else:
    print "no match found"
*********
"""

print "number of groups matched =", len(mtch.group())

if mtch:
    print "matched: ", mtch.group()
    for g in mtch.group():
        print "matched group is %s - value is '%s'" %(type(g), g)
else:
    print "no match found"
    
pause()

print """
*********

pat = re.compile("(abcd)")
print "pat is a", type(pat)

mtch = pat.search(s)
print "mtch is a", mtch

print len(mtch.group())

if mtch:
    print "matched: ", mtch.group()
    for g in mtch.group():
        print "matched group is %s - value is '%s'" %(type(g), g)
else:
    print "no match found"
*********
"""

pat = re.compile("(abcd)")
print "pat is a", type(pat)

mtch = pat.search(s)
print "mtch is a", mtch

print len(mtch.group())

if mtch:
    print "matched: ", mtch.group()
    for g in mtch.group():
        print "matched group is %s - value is '%s'" %(type(g), g)
else:
    print "no match found"
    
pause()

print """
*********
pat = re.compile("(abcd)", re.IGNORECASE)
print "pat is a", type(pat)

mtch = pat.search(s)
print "mtch is a", mtch

print "number of groups matched =", len(mtch.group())

if mtch:
    print "matched: ", mtch.group()
    for g in mtch.group():
        print "matched group is %s - value is '%s'" %(type(g), g)
else:
    print "no match found"
*********
"""

pat = re.compile("(abcd)", re.IGNORECASE)
print "pat is a", type(pat)

mtch = pat.search(s)
print "mtch is a", mtch

print "number of groups matched =", len(mtch.group())

if mtch:
    print "matched: ", mtch.group()
    for g in mtch.group():
        print "matched group is %s - value is '%s'" %(type(g), g)
else:
    print "no match found"
    
pause()

print """
*********
*********
"""

s = "Now is the time"
pat = re.compile(r"(\w+) is the (\w+)")
mtch = pat.search(s)
if mtch:
    print "matched: ", mtch.group()
    
