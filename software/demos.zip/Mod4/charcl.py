#################################
#
#   File:    charcl.py
#
#   Description
#
#   Demonstrate character classes
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause

print """
*********
import re

patt = re.compile(r'([0-9]+)')    # digit character class
m = patt.search("12345")
print "match.group() - character class: ", m.group()
m = patt.search("test123456")
print "match.group() - character class: ", m.group()
m = patt.search("789 test")
print "match.group() - character class: ", m.group()
*********
"""

from pause import pause

import re

patt = re.compile(r'([0-9]+)')
m = patt.search("12345")
print "match.group() - character class: ", m.group()
m = patt.search("test123456")
print "match.group() - character class: ", m.group()
m = patt.search("789 test")
print "match.group() - character class: ", m.group()

pause()

print """
*********
patt = re.compile(r'([^0-9]+)')    # negate digit character class
m = patt.search("12345")
print "match.group() - character class: ", m.group()
m = patt.search("test123456")
print "match.group() - character class: ", m.group()
m = patt.search("789 test")
print "match.group() - character class: ", m.group()
*********
"""

patt = re.compile(r'([^0-9]+)')
m = patt.search("12345")
if m:
    print "match.group() - character class: ", m.group()
else:
    print "no match for '12345'"

m = patt.search("test123456")
print "match.group() - character class: ", m.group()
m = patt.search("789 test")
print "match.group() - character class: ", m.group()

pause()

print """
*********
patt = re.compile(r"(\d+)")        # digit sequence
m = patt.search("12345")
print "match.group() - \\d sequence: ", m.group()
print "match.group() - \\d sequence: ", m.group()
m = patt.search("test123456")
print "match.group() - \\d sequence: ", m.group()
m = patt.search("789 test")
print "match.group() - \\d sequence: ", m.group()
*********
"""

patt = re.compile(r"(\d+)")
m = patt.search("12345")
print "match.group() - \\d sequence: ", m.group()
m = patt.search("test123456")
print "match.group() - \\d sequence: ", m.group()
m = patt.search("789 test")
print "match.group() - \\d sequence: ", m.group()
