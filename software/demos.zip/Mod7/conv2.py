#################################
#
#   File:    conv2.py
#
#   Description
#
#   Demonstrate jarray objects
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import jarray

# integers
jint = jarray.zeros(10, 'i')
print "jarray.zeros(10, 'i') =", jint, " and is a ", type(jint)

print "a jarray type can be indexed and sliced"

print "iteration"
for val in jint:
    print "val =", val, " and is a", type(val)

print "index: jint[2] =", jint[2], "; jint[-1] =", jint[-1], "; jint[:2] =", jint[:2]
*********
"""

from pause import pause

import jarray

jint = jarray.zeros(10, 'i')
print "jarray.zeros(10, 'i') =", jint, " and is a ", type(jint)

print "a jarray type can be indexed and sliced"

print "iteration"
for val in jint:
    print "val =", val, " and is a", type(val)

print "index: jint[2] =", jint[2], "; jint[-1] =", jint[-1], "; jint[:2] =", jint[:2]

pause()

print """
*********
# boolean
jint = jarray.zeros(10, 'i')
print "jarray.zeros(10, 'i') =", jint, " and is a ", type(jint)
****
"""

jbool = jarray.zeros(2, 'z')
print "jarray.zeros(2, 'z') =", jbool, " and is a ", type(jbool)

pause()

print """
*********
# string

import java.lang

jstr = jarray.zeros(2, java.lang.String)
print "jarray.zeros(2, java.lang.String) =", jstr, " and is a ", type(jstr)
****
"""
import java.lang

jstr = jarray.zeros(2, java.lang.String)
print "jarray.zeros(2, java.lang.String) =", jstr, " and is a ", type(jstr)

pause()

print """
*********
# long

jlong = jarray.array([2, -1, 4j], 'l')
print "jarray.aray([2, -1, 4j], 'l') =", jlong, " and is a ", type(jlong)
****
"""

jlong = jarray.array([2, -1, 4j], 'l')
print "jarray.aray([2, -1, 4j], 'l') =", jlong, " and is a ", type(jlong)