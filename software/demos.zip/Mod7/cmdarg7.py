#################################
#
#   File:`cmdarg7.py
#
#   Description
#
#   Demonstrate swicthes and positional args
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import argparse

import argparse

parser = argparse.ArgumentParser()
parser.add_argument("square", type=int, help="display a square of a given number")
parser.add_argument("-v", "--verbose", action="store_true", help="increase output verbosity")
args = parser.parse_args()
print "args.verbose =", args.verbose, " and is a ", type(args)
print "args.square =", args.square, " and is a ", type(args)
answer = args.square**2
if args.verbose:
    print "{} ^ 2 = {}".format(args.square, answer)
else:
    print answer
*********
"""

import argparse

parser = argparse.ArgumentParser()
parser.add_argument("square", type=int, help="display a square of a given number")
parser.add_argument("-v", "--verbose", action="store_true", help="increase output verbosity")
args = parser.parse_args()
print "args.verbose =", args.verbose, " and is a ", type(args)
print "args.square =", args.square, " and is a ", type(args)
answer = args.square**2
if args.verbose:
    print "{} ^ 2 = {}".format(args.square, answer)
else:
    print answer