#################################
#
#   File:    jython1.py
#
#   Description
#
#   Demonstrate use of Java classes in Jython
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
from java.lang import Math

print "Math.max(-1, 10) =", Math.max(-1, 10)
print "Math.pow(7,2) =", Math.pow(7, 2)
print "Math.abs(-9.1) =", Math.abs(-9.1)

from java.lang import System as jsys

jsys.out.println("Test")
*********
"""

from java.lang import Math

print "Math.max(-1, 10) =", Math.max(-1, 10)
print "Math.pow(7,2) =", Math.pow(7, 2)
print "Math.abs(-9.1) =", Math.abs(-9.1)

from java.lang import System as jsys

print "jsys.out.println(\"Test\"):"; jsys.out.println("\tTest")