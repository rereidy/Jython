public class MentalState {
   
    public int energy;

    public MentalState(int e) {
        this.energy = e;
    }

    public int askEnergy() { return energy; }
}

