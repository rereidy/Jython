from os import getenv
import sys

der = getenv('DEMOS')
sys.path.append('%s/Mod7' %der)

import HelloWorld

h = HelloWorld()
h.hello()
h.hello("Ron")

