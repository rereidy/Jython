from java.awt import Dimension 
from javax.swing import JWindow 

win = JWindow()
win.setSize( Dimension( 400, 100 ) )
win.show()
