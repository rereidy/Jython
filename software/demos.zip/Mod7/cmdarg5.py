#################################
#
#   File:    cmdarg5.py
#
#   Description
#
#   Demonstrate argparse optional arguments
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import argparse

parser = argparse.ArgumentParser("optional args")
parser.add_argument("--verbose", help="increase output verbosity", action="store_true")
args = parser.parse_args()
print "args.verbose =", args.verbose, " and is a ", type(args)
if args.verbose:
   print "verbosity turned on"
*********
"""

import argparse

parser = argparse.ArgumentParser("optional args")
parser.add_argument("--verbose", help="increase output verbosity", action="store_true")
args = parser.parse_args()
print "args.verbose =", args.verbose, " and is a ", type(args)
if args.verbose:
   print "verbosity turned on"