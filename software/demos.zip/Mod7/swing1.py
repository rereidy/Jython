from javax.swing import JFrame

w = JFrame("Jython Swing program")
w.size = (400, 100)
w.show()
