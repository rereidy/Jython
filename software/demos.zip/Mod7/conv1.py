#################################
#
#   File:    conv1.py
#
#   Description
#
#   Demonstrate conversion of Java objects to Jython objects
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import java

vec = java.util.Vector()
vec.add(3)
print "vec =", vec, " and is a ", type(vec)
*********
"""

from pause import pause

import java

vec = java.util.Vector()
vec.add(3)
print "vec =", vec, " and is a ", type(vec)

pause()

print """
*********
Add a short type

vec.add(java.lang.Short(9))
print "vec =", vec, " and is a ", type(vec)
*********
"""

vec.add(java.lang.Short(9))
print "vec =", vec, " and is a ", type(vec)

pause()

print """
*********
Add a long type

vec.add(java.lang.Long(2))
print "vec =", vec, " and is a ", type(vec)
*********
"""

vec.add(java.lang.Long(2))
print "vec =", vec, " and is a ", type(vec)

pause()

print """
*********
Add a boolean type

vec.add(java.lang.Boolean(0))
print "vec =", vec, " and is a ", type(vec)
*********
"""

vec.add(java.lang.Boolean(0))
print "vec =", vec, " and is a ", type(vec)

print """
*********
Print the values in the vec name
*********
"""

pause()

for v in vec:
    print "v =", v, " and is a", type(v)