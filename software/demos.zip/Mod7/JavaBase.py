from __future__ import with_statement
#################################
#
#   File:    JavaBase.py
#
#   Description
#
#   Demonstrate inheriting Java class
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import JavaBase
"""

from read_src import source_reader

import JavaBase

class SnakeClass(JavaBase):
    def __init__(self):
        pass
    
    def one(self):
        return "snake-one(%s)" % self.super__two()

    def two(self):
        return "snake-two(%s)"  % JavaBase.one(self)

java_source = source_reader('/Users/rereidy/Documents/workspace/Jython/class/demos/Mod8/JavaBase.java')
for l in java_source:
    print l

print """
class SnakeClass(JavaBase):
  def one(self):
    return "snake-one(%s)" % self.super__two()

  def two(self):
    return "snake-two(%s)"  % JavaBase.one(self)

snake=SnakeClass()
print JavaBase.callOne(snake)
print JavaBase.callTwo(snake)
********
"""

snake=SnakeClass()
print JavaBase.callOne(snake)
print JavaBase.callTwo(snake)
