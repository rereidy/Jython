#################################
#
#   File:   jtab.py
#
#   Description
#
#   Demonstrate JTable in Jython
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from javax.swing import *
from java.awt import *
class Example:
    def __init__(self):
        frame = JFrame("Jython JTable")
        frame.setSize(400, 300)
        frame.setLayout(BorderLayout())
        splitPane = JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        label1 = JLabel("This is a panel1")
        panel1 = JPanel()
        panel1.add(label1)
        splitPane.setLeftComponent(panel1);
        label2 = JLabel("This is a panel2")
        panel2 = JPanel()
        panel2.add(label2)
        splitPane.setRightComponent(panel2);
        splitPane.setDividerLocation(150);
        frame.add(splitPane)
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE)
        frame.setVisible(True)

if __name__ == '__main__':
    Example()