import sys
from os.path import basename

def print_classes(jclass, pad = ' '):
    try:
        print pad + str(jclass)
        for bases in jclass.__bases__:
            print_classes(bases, pad + '| ')
    except:
        raise

if __name__ == "__main__":
    if len(sys.argv) < 2:
        scr = basename(sys.argv[0])
        print """
%s - print Java class hierarchy of a class
usage is: %s java_class
""" %(scr, scr)
    else:
        __import__(sys.argv[1])
        c = Class(sys.argv[1])
        cls = sys.argv[1].split(".")[-1]
        print_classes(cls)
        
    sys.exit(0)