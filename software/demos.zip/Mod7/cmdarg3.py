#################################
#
#   File:    cmdarg3.py
#
#   Description
#
#   Demonstrate argparse module
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
from ver2_6 import v2_6

v2_6()

import argparse

parser = argparse.ArgumentParser("Positional arg parser")
parser.add_argument("echo")
args = parser.parse_args()
print args.echo
*********
"""

from ver2_6 import v2_6

v2_6()

import argparse

parser = argparse.ArgumentParser("Positional arg parser")
parser.add_argument("echo")
args = parser.parse_args()
print args.echo