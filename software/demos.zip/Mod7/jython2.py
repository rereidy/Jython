#################################
#
#   File:    jython2.py
#
#   Description
#
#   Demonstrate Java and Jython string methods
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
from java.lang import String

x = String("Test")
print "string x =", x, " and is a", type(x)
*********
"""

from pause import pause

from java.lang import String

x = String("Test")
print "string x =", x, " and is a", type(x)

pause()

print """
*********
print "Jython version: %s.startsWith('T') =" %x, x.startsWith('T')
print "Java version: String.startsWith(%s, 'T') =" %x, String.startsWith(x, 'T')
*********
"""

print "Jython version: %s.startsWith('T') =" %x, x.startsWith('T')
print "Java version: String.startsWith(%s, 'T') =" %x, String.startsWith(x, 'T')