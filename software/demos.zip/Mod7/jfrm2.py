#################################
#
#   File:    jfrm2.py
#
#   Description
#
#   Demonstrate JFrame Swing program with exitonclose attribute
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
from javax.swing import JFrame

win = JFrame('Jython Swing - first JFrame program')
win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)    # exits Jython when window closes
win.size = ( 400, 100 )
win.show()
*********
"""

from javax.swing import JFrame

win = JFrame('Jython Swing - first JFrame program')
win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)
win.size = ( 400, 100 )
win.show() 

