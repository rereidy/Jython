#################################
#
#   File:    conv3.py
#
#   Description
#
#   Demonstrate Java to Jython conversion
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
from java.lang import Integer, Boolean, Double

# boolean

jy_false = Boolean.FALSE
print "Boolean.FALSE =", jy_false, " and is a ", type(jy_false)
print "Boolean constructor: Boolean(0) =", Boolean(0), " and is a ", type(Boolean(0))
*********
"""

from pause import pause

from java.lang import Integer, Boolean, Double

jy_false = Boolean.FALSE
print "Boolean.FALSE =", jy_false, " and is a ", type(jy_false)
print "Boolean constructor: Boolean(0) =", Boolean(0), " and is a ", type(Boolean(0))

pause()

print """
*********
# double

jy_dbl = Double(3.14)
print "Double(3.14) =", jy_dbl, " and is a", type(jy_dbl)
*********
"""

jy_dbl = Double(3.14)
print "Double(3.14) =", jy_dbl, " and is a", type(jy_dbl)

pause()

print """
*********
# integer

jy_int = Integer(3)
print "Integer(3) =", jy_int, " and is a", type(jy_int)
*********
"""

jy_int = Integer(3)
print "Integer(3) =", jy_int, " and is a", type(jy_int)

pause()

print """
*********
import jarray

arr = jarray.zeros(1, Integer)
print "jarray.zeros(1, Ingeter) =", arr, " and is a ", type(arr)

arr[0] = jy_int

# False because conversion to Python integer fails
print "isinstance(arr[0], jy_int.__class__) =", isinstance(arr[0], jy_int.__class__)    
*********
"""

import jarray

arr = jarray.zeros(1, Integer)
print "jarray.zeros(1, Ingeter) =", arr, " and is a ", type(arr)

arr[0] = jy_int

print "isinstance(arr[0], %s) ( %s is a" %(jy_int, jy_int), type(jy_int), ") =", isinstance(arr[0], jy_int.__class__)
