print """
*********
from java import util as jutil

ht = jutil.Hashtable()

ht['one'] = 1
ht['two'] = 2

print "ht =", ht, " and is a ", type(ht)

ht[3] = 'three'
print "ht =", ht, " and is a ", type(ht)

del ht[3]
print "ht =", ht, " and is a ", type(ht)

for h in ht.keys():
    print "%s: %s" %(h, ht[h]), " h is a", type(h), " and ht[%s] is a" %h, type(ht[h])
*********
"""

from java import util as jutil

ht = jutil.Hashtable()

ht['one'] = 1
ht['two'] = 2

print "ht =", ht, " and is a ", type(ht)

ht[3] = 'three'
print "ht =", ht, " and is a ", type(ht)

del ht[3]
print "ht =", ht, " and is a ", type(ht)

for h in ht.keys():
    print "%s: %s" %(h, ht[h]), " h is a", type(h), " and ht[%s] is a" %h, type(ht[h])