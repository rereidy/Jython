#################################
#
#   File:    cmdarg2.py
#
#   Description
#
#   Demonstrate getopt module
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import sys
import getopt

ifile=None
ofile=None
 
if len(sys.argv) < 2:
    print "Usage: %s -i input -o output" % sys.argv[0]
else:
    myopts, args = getopt.getopt(sys.argv[1:],"i:o:")

    for o, a in myopts:
        if o == '-i':
            ifile=a
        elif o == '-o':
            ofile=a
        else:
            print "Usage: %s -i input -o output" % sys.argv[0]

    print "Input file : %s\nOutput file: %s" % (ifile,ofile)
*********
"""

import sys
import getopt

ifile=None
ofile=None
 
if len(sys.argv) < 2:
    print "Usage: %s -i input -o output" % sys.argv[0]
else:
    myopts, args = getopt.getopt(sys.argv[1:],"i:o:")

    for o, a in myopts:
        if o == '-i':
            ifile=a
        elif o == '-o':
            ofile=a
        else:
            print "Usage: %s -i input -o output" % sys.argv[0]

    print "Input file : %s\nOutput file: %s" % (ifile,ofile)