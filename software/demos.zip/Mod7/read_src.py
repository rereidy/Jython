from __future__ import with_statement

from os.path import basename

def source_reader(fname, print_with_filename=True):
    with open(fname, 'r') as f:
        fn = basename(f.name)
        for line in iter(f):
            out = None
            if print_with_filename:
                out = "%s: %s" %(fn, line.rstrip("\n"))
            else:
                out = line.rstrip('\n')
            
            yield out
