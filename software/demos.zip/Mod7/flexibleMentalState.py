from __future__ import with_statement

print """
*********
import MentalState        # java class

"""

from pause import pause
from read_src import source_reader

from os.path import basename

import MentalState

class FlexibleMentalState(MentalState):
    pass

if __name__ == '__main__':
    for line in source_reader('/Users/rereidy/Documents/workspace/Jython/class/demos/Mod7/MentalState.java'):
        print line

    print """
class FlexibleMentalState(MentalState):
    pass

if __name__ == '__main__':
    flexible = FlexibleMentalState(3)
    print flexible.askEnergy()
*********
"""
    flexible = FlexibleMentalState(3)
    print "flexible.askEnergy() =", flexible.askEnergy(), " and flexible is a", type(flexible)
    
    pause()
    
    print """
*********
    try:
        mental = MentalState(-1)
        print "mental is a", type(mental)
        mental.joy = 5                    # this will fail; cannot set attributes of Java class directly
    except AttributeError, e:
        print "exception: ", e
*********
"""

    try:
        mental = MentalState(-1)
        print "mental is a", type(mental)
        mental.joy = 5
    except AttributeError, e:
        print "exception: ", e
        
    pause()

    print """
*********
    mental = FlexibleMentalState(-1)
    mental.joy = 5
    print "mental attributes =", mental.__dict__, "; mental is a ", type(mental)
*********
"""

    mental = FlexibleMentalState(-1)
    mental.joy = 5
    print "mental attributes =", mental.__dict__, "; mental is a ", type(mental)
