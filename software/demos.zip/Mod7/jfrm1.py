#################################
#
#   File:    jfrm1.py
#
#   Description
#
#   Demonstrate JFrame Swing program
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
from javax.swing import JFrame

win = JFrame('Jython Swing - first JFrame program')
win.size = ( 400, 100 )
win.show()
*********
"""

from javax.swing import JFrame

win = JFrame('Jython Swing - first JFrame program')
win.size = ( 400, 100 )
win.show() 

