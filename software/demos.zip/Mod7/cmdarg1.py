#################################
#
#   File:    cmdarg1.py
#
#   Description
#
#   Demonstrate positional command line args using sys.argv
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import sys

i = 0
for a in sys.argv:
    print "%d: arg=%s" %(i, a)
    i += 1
*********
"""
from pause import pause


import sys

i = 0
for a in sys.argv:
    print "%d: arg=%s" %(i, a)
    i += 1
    
pause()

print """
*********
i = len(sys.argv)
sys.argv.reverse()
for a in sys.argv:
    print "%d: arg=%s" %(i, a)
    i -= 1
*********
"""

i = len(sys.argv)
sys.argv.reverse()
for a in sys.argv:
    print "%d: arg=%s" %(i, a)
    i -= 1