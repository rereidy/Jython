#################################
#
#   File:    olCaller.py
#
#   Description
#
#   Demonstrate overloading Java from Jython
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import sys
sys.path.append('/Users/rereidy/Documents/workspace/Jython/class/demos/Mod7')

print "sys.path: ", "\n".join(sys.path)

import OverloadExample
import java

x = OverloadExample()
x.method(3)
x.method(java.lang.Integer(3))
x.method("3")
x.method([1, 2])
x.method(1, 2)
*********
"""

import sys
sys.path.append('/Users/rereidy/Documents/workspace/Jython/class/demos/Mod7')

print "sys.path: ", "\n".join(sys.path)

import OverloadExample
import java

x = OverloadExample()
x.method(3)
x.method(java.lang.Integer(3))
x.method("3")
x.method([1, 2])
x.method(1, 2)
