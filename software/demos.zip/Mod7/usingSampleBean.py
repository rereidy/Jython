#################################
#
#   File:    usingSampleBean.py
#
#   Description
#
#   Demonstrate JavaBean property access
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause

print """
*********
import SampleBean

"""

from os import getenv

der = getenv('DEMOS')

from read_src import source_reader
for line in source_reader('%s/Mod7/SampleBean.java' %der):
    print line

print """
beanInstance = SampleBean()

print beanInstance.stringProperty
print beanInstance.integerProperty

beanInstance.stringProperty += " and reset"
beanInstance.integerProperty += 1

print beanInstance.stringProperty
print beanInstance.integerProperty
*********
"""

import SampleBean
beanInstance = SampleBean()

print beanInstance.stringProperty
print beanInstance.integerProperty

beanInstance.stringProperty += " and reset"
beanInstance.integerProperty += 1

print beanInstance.stringProperty
print beanInstance.integerProperty

pause()

print """
*********
How to get property names in Jython

import java.beans

def dump_properties(beancl):
    info = java.beans.Introspector.getBeanInfo(beancl)
    props = info.getPropertyDescriptors()
    for p in props:
        print "Property: %s" %(p.name)

dump_properties(SampleBean)
*********
"""

import java.beans

def dump_properties(beancl):
    info = java.beans.Introspector.getBeanInfo(beancl)
    props = info.getPropertyDescriptors()
    for p in props:
        print "Property: %s" %(p.name)

dump_properties(SampleBean)