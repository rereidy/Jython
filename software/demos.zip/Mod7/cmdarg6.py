#################################
#
#   File:    cmgarg6.py
#
#   Description
#
#   Demonstrate short and long argument stayles
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("-v", "--verbose", help="increase output verbosity", action="store_true")
args = parser.parse_args()
print "args.verbose =", args.verbose, " and is a ", type(args)
if args.verbose:
    print "verbosity turned on"
*********
"""

import argparse

parser = argparse.ArgumentParser()
parser.add_argument("-v", "--verbose", help="increase output verbosity", action="store_true")
args = parser.parse_args()
print "args.verbose =", args.verbose, " and is a ", type(args)
if args.verbose:
    print "verbosity turned on"