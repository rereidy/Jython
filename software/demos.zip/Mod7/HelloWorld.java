public class HelloWorld {
    public void hello() {
        System.out.println("Hello World!\n");
    }
    public void hello(String name) {
        System.out.printf("Hello %s!\n", name);
    }
}


