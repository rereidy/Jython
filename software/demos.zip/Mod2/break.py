#################################
#
#   File:    break.py
#
#   Description
#
#    Demonstrate Python break statement
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
numbers = (1, 2, 3, 4, 5, 6, 7, 8, 9) 
num_sum = 0  
count = 0  
for x in numbers:  
    num_sum = num_sum + x  
    count = count + 1   
    if count == 5:  
        break

print "Sum of first ",count,"integers is : ", num_sum
"""

numbers = (1, 2, 3, 4, 5, 6, 7, 8, 9) 
num_sum = 0  
count = 0  
for x in numbers:  
    num_sum = num_sum + x  
    count = count + 1   
    if count == 5:  
        break

print "Sum of first ",count,"integers is : ", num_sum