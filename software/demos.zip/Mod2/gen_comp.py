#################################
#
#   File:    gen_comp.py
#
#   Description
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
gen_comp = (x ** 2 for x in range(20))
print "gen_comp is", type(gen_comp)
print gen_comp
    
gen_comp_list = list(gen_comp)
print "gen_comp_list is", type(gen_comp_list)
print gen_comp_list
*********
"""

from ver2_6 import v2_6

v2_6()
    
gen_comp = (x ** 2 for x in range(20))
print "gen_comp is", type(gen_comp)
print gen_comp
    
gen_comp_list = list(gen_comp)
print "gen_comp_list is", type(gen_comp_list)
print gen_comp_list
