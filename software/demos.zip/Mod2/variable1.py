#################################
#
#   File:    variable1.py
#
#   Description
#
#    Demonstrate objects and name association in Python
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
x = 1
print "x is", type(x)
*********
"""

x = 1
print "x is", type(x)

raw_input()

print """
*********
x = 1.0
print "x is", type(x)
*********
"""
x = 1.0
print "x is", type(x)

