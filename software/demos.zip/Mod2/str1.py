print """
*********
str_seq = "Now is the time for all good men to come to the aid of their \\"country\\""
print "str (%d) = %s" %(len(str_seq), str_seq)

raw_str = r"This is a string with a CRLF embedded\\n"
print "%s" %raw_str

s = "    Test     "
print "len(s) = %d" %len(s)
print ">%s< - %d" %(s.rstrip(), len(s.rstrip()))    # strip white space from right
print ">%s< - %d" %(s,lstrip(), len(s.lstrip()))    # strip white space from left
print ">%s< - %d" %(s.strip(), len(x.strip()))      # strip white space from both sides
*********
"""

str_seq = "Now is the time for all good men to come to the aid of their \"country\""
print "str (%d) = %s" %(len(str_seq), str_seq)

raw_str = r"This is a string with a CRLF embedded\n"
print "%s" %raw_str

s = "    Test     "
print "len(s) = %d" %len(s)
print ">%s< - %d" %(s.rstrip(), len(s.rstrip()))    # strip white space from right
print ">%s< - %d" %(s.lstrip(), len(s.lstrip()))    # strip white space from left
print ">%s< - %d" %(s.strip(), len(s.strip()))      # strip white space from both sides