#################################
#
#   File:    switch.py
#
#   Description
#
#    Demonstrate if ... elif ... else structure
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
x = 2
if x == 0:
    print "x == 0"
elif x < 0:
    print "x < 0"
elif x == 1:
    print "x == 1"
else:
    print "x is something else:", x
*********
"""

x = 2
if x == 0:
    print "x == 0"
elif x < 0:
    print "x < 0"
elif x == 1:
    print "x == 1"
else:
    print "x is something else:", x