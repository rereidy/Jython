#################################
#
#   File:    dict_comp1.py
#
#   Description
#
#   Demonstrate dictionary comprehension
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause

print """
*********
import os, glob

file_md = { f:os.stat(f) for f in glob.glob(os.path.join(os.environ['HOME'],"*")) if os.access(f, os.X_OK) and not os.path.isdir(f) }
print "files that are world executable: ", file_md.keys()
*********
"""

import os, glob

file_md = { f:os.stat(f) for f in glob.glob(os.path.join(os.environ['HOME'],"*")) if os.access(f, os.X_OK) and not os.path.isdir(f) }
print "files that are world executable: ", file_md.keys()
