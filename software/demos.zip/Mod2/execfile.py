print "execfile test - this will be displayed on sys.stdout"
import math
x = math.cos(7.0)
print "math.cos(7.0): %f" %(x), " and is a ", type(x)
print "no variables are stored into globals or locals in the execfile() call"