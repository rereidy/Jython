/*###############################
#
#   File:   switch.c
#
#   Description
#
#   Demonstrate the switch statement in C
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
###############################*/


#include <stdio.h>

int main(void)
{
    char c = 'a';
    switch (c) {
        case 'z':
            printf("z\n");
        case 'y':
            printf("y\n");
        default:
            printf("not tested\n");
    }
}
