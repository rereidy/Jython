#################################
#
#   File:    compile.py
#
#   Description
#
#   Demonstrate compile statement
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
def compNrun(code, res):
    exec code
    return res

co = compile("res = res + 10", '<string>', 'exec')
*********
"""

def compNrun(code, res):
    exec code
    return res

co = compile("res = res + 10", '<string>', 'exec')

print "compNrun(co, 10) =", compNrun(co, 1)
