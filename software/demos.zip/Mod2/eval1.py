#################################
#
#   File:    eval1.py
#
#   Description
#
#    Demonstrate eval() usage
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
def dmp(expression):
    result = eval(expression)
    print expression, "=>", result, type(result)
    
z = None
print "dmp('z'): ", dmp('z')
print "dmp('1.0 == 1'): ", dmp('1.0 == 1')
print "dmp(\"len('test')\": ", dmp("len('test')")
*********
"""

def dmp(expression):
    result = eval(expression)
    return "expression '%s' evals as '%s' and is a %s" %(expression, result, type(result))

z = None
print "dmp('z'): ", dmp('z')
print "dmp('1.0 == 1'): ", dmp('1.0 == 1')
print "dmp(\"len('test')\": ", dmp("len('test')")