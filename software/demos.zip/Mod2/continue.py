#################################
#
#   File:    continue.py
#
#   Description
#
#    Demonstrate continue statement in Python
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
for x in range(7):  
    if (x == 3 or x==6):
        print "skipping for x=%d" % x
        continue  
    print(x)
"""

for x in range(7):  
    if (x == 3 or x==6):
        print "skipping for x=%d" % x
        continue  
    print(x)