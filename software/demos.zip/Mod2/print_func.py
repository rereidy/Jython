print """
from __future__ import print_function
import sys

print("test", file=sys.stdout)
"""

from __future__ import print_function
import sys

print("test", file=sys.stdout)