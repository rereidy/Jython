print """
print "test"

import math
print "print PI =", math.pi
"""

print "test"

import math
print "print PI =", math.pi