print """
*********
Sets can have any type:

str_set = set("A test string")
print "str_set =", str_set
print "str_set is", type(str_set)
*********
"""

str_set = set("A test string")
print "str_set =", str_set
print "str_set is", type(str_set)

list_set = set(['Jython', 'Java'])
print "list_set =", list_set
print "list_set is", type(list_set)

dict_set = set(dict("d1" : None, "d2": None))
print "dict_set =", dict_set
print "dict_set is", type(dict_set)