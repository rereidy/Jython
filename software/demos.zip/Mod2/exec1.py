#################################
#
#   File:
#
#   Description
#
#   Demonstrate
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

from pause import pause

print """
*********
co = compile("x = 1", '<string>', 'exec')

code_globals = {}
code_locals  = {}

exec co in code_globals
print "exec compile('x = 1', '<string>', 'exec'): ", code_globals['x']

exec co in code_locals
print "exec compile('x = 1', '<string>', 'exec'): ", code_locals['x']

exec co in code_globals, code_locals
print "exec compile('x = 1', '<string>', 'exec'): code_globals =", code_globals, "; code_locals =", code_locals
*********
"""

co = compile("x = 1", '<string>', 'exec')

code_globals = {}
code_locals  = {}

exec co in code_globals
print "exec compile('x = 1', '<string>', 'exec'): ", code_globals['x']

exec co in code_locals
print "exec compile('x = 1', '<string>', 'exec'): ", code_locals['x']

exec co in code_globals, code_locals
print "exec compile('x = 1', '<string>', 'exec'): code_globals =", code_globals['x'], "; code_locals =", code_locals['x']

pause()

print """
*********
execfname = "%s/Mod2/execfile.py" %(getenv('DEMOS'))
print "cd execfile(%s) " %execfname
execfile(execfname)
*********
"""

from os import getenv

execfname = "%s/Mod2/execfile.py" %(getenv('DEMOS'))
print "cd execfile(%s) " %execfname
execfile(execfname)

pause()

print """
*********
print "eval('42'): %s" %(eval('42'))    # prints "42"
print "exec('42'): ",
exec('42')            # no output
*********
"""

print "eval('42'): %s" %(eval('42'))
print "exec('42'): ",
exec('42')
