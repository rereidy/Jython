from sys import version_info
"""
ver2_6 - test Python interpreter is 2.6 or greater

Raise ValueError if Python version < 2.6
"""

def v2_6():
    ver = version_info[:2]
    if ver < (2, 6):
        raise ValueError("Must be using Python 2.6 or greater; using %d.%d" %ver)
