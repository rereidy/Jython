"""
pause - emulate the Pause windows command
"""

def pause(prompt="\nPress <CR> to continue ..."):
    raw_input(prompt)