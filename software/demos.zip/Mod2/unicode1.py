#################################
#
#   File:    unicode1.py
#
#   Description
#
#   Demonstrate unicode
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
unicode_literal = u'abcdefg'
print "unicode_literal = %r" %unicode_literal, " and is a", type(unicode_literal)

uc_assign = unicode('hijklmn')
print "uc_assign = %r" %uc_assign, " and is a", type(uc_assign)
*********
"""

unicode_literal = u'abcdefg'
print "unicode_literal = %r" %unicode_literal, " and is a", type(unicode_literal)

uc_assign = unicode('hijklmn')
print "uc_assign = %r" %uc_assign, " and is a", type(uc_assign)
