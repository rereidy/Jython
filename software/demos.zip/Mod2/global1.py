from os import system
import java.lang

system_name = java.lang.System.getProperty("os.name")

def cls():
    if system_name.lower().startswith("mac") or system_name.lower().startswith("unix"):
        system("clear")
    elif system_name.lower().startswith("win"):
        system("cls")
    else:
        print "cannot determine how to clear screen"    

cls()
print """
*********
def f():
    print "f() ", s    # prints the "s" defined outside the function (no other "s" found)
    
s = "I play golf"
f()
*********
"""
raw_input("Press return")
def f():
    print "f() ", s
    
s = "I play golf"
f()

raw_input()
cls()

print """
*********
def f1(): 
    s = "Me too."
    print "f1() ", s    # print the "s" defined in the function

f1()
print "outside f1()", s
**********
"""
raw_input("Press return")

def f1(): 
    s = "Me too."
    print "f1() ", s 

f1()
print "outside f1()", s

raw_input()
cls()

print """
**********
def f2(): 
    try:
        print "f2() #1 ", s    # throw exception - no "s" defined
        s = "Me too."
        print "f2() #2 ", s
    except UnboundLocalError, e:
        print e

f2()
print "outside f2() ", s        # print "s" defined outside f2()
*********
"""
raw_input("Press return")
def f2(): 
    try:
        print "f2() #1 ", s
        s = "Me too."
        print "f2() #2 ", s
    except UnboundLocalError, e:
        print e

f2()
print "outside f2() ", s

raw_input()
cls()

print """
*********
def f3():
    global s                # tell Python "s" is global - reference
    print "f3() - global value: ",s
    s = "That's clear."    # set "s" to new value
    print "f3() - new value: ", s 

f3()
print "outside f3() ", s                    # "s" has been changed
*********
"""

raw_input("Press return")
def f3():
    global s
    print "f3() - global value: ",s
    s = "That's clear."
    print "f3() - new value: ", s 

f3()
print "outside f3() ", s

raw_input()
cls()

print """
*********
def f4():
    s1 = "I am globally not known"
    print "f4() ", s1 

f4()
try:
    print "outside f4() ", s1
except NameError, e:
        print "EXCEPTION:", e
*********
"""
raw_input()
def f4():
    s1 = "I am globally not known"
    print "f4() ", s1 

f4()
try:
    print "outside f4() ", s1
except NameError, e:
        print "EXCEPTION:", e
        
raw_input()
cls()

print """
*********
find variable scope

global() - list of global variables in the global system table
if s in globals():
    print "s in globals():", s in globals()
else:
    print "s NOT in globals():", s not in globals()

local() - list of all local variables
if s in locals():
    print "s in locals():", s in locals()
else:
    print "s NOT in locals():", s not in locals()
*********
"""
print "s=", s

gl = globals()
for k in gl.keys():
    print "global %s -> %s" %(k, gl[k])

if s in globals():
    print "s in globals():", s in globals()
else:
    print "s NOT in globals():", s not in globals()

raw_input()

loc = locals()
for k in loc.keys():
    print "local %s -> %s" %(k, loc[k])
        
if s in locals():
    print "s in locals():", s in locals()
else:
    print "s NOT in locals():", s not in locals()