class test(object):
    def __init__(self, xx=1, **kwargs):
        self.xx = xx
        for i in kwargs.keys():
            self.i = kwargs[i]
    
    def __dir__(self):
        pass
    
    def __repr__(self):
        pass


if __name__ == "__main__":
    d = {'arg1' : 1, "arg2" : [1,2,3,4], "arg3" : {'one': 1, 'two' : "two"}}
    c = test(2, d)
    
    print "here"
    