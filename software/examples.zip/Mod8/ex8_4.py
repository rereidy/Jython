# ex8_4.py

import java

import unittest

class JavaTypetest(unittest.TestCase):
    def testJavaDouble(self):
        jdbl = java.lang.Double(7.0)
        self.assertTrue(isinstance(jdbl, java.lang.Double), 'jdbl is not a java.lang.Double')
        self.assertTrue(isinstance(float(7), type(float(str(jdbl)))), 'java.lang.Double does not convert to a float')

    def testJavaShort(self):
        jshort = java.lang.Short(1)
        self.assertFalse(isinstance(jshort, type(java.lang.Short)), 'jshort is a java.Lang.Short')
        self.assertTrue(isinstance(int(str(jshort)), int), 'Jython int == java.lang.Short')

    def testJavaByte(self):
        jbyte = java.lang.Byte(1)
        self.assertTrue(isinstance(jbyte, java.lang.Byte), 'jbyte is not a java.lang.Byte')
        self.assertTrue(isinstance(int(str(jbyte)), int), 'Jython int == java.lang.Short')

if __name__ == "__main__":
    unittest.main()