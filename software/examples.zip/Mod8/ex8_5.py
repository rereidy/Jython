# ex8_5.py

import pdb
import math

def func1():
    pdb.set_trace()
    print "starting func1()"
    try:
        s = math.sqrt(1j)
        pdb.set_trace()
    except Exception, e:
        pdb.set_trace()
        print e

if __name__ == "__main__":
    pdb.set_trace()
    func1()