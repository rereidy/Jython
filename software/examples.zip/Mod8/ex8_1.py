# ex8_1.py

import java

class D():
    def __init__(self):
        """
        >>> D() #doctest: +ELLIPSIS
        <__main__.D instance at 0xe...>
        """
        pass

    def f0(self):
        """
        >>> D().f0()
        'hello from f0'
        """
        return "hello from f0"

    def f1(self, a, b):
        """
        >>> D().f1(5, 'x')
        'xxxxx'
        """
        return a*b

    def f2(self, a, b=None):
        """
        >>> D().f2(10)
        Traceback (most recent call last):
          File "<stdin>", line 1, in <module>
        TypeError: unsupported operand type(s) for *: 'int' and 'NoneType'

        >>> D().f2(10,10)
        100
        """
        return a*b

def func1(a,b, c=0):
    """
    >>> func1(7, 'a', java.lang.Integer(1))
    'aaaaaaa'

    >>> func1(8, 'b', 2)
    'bbbbbbbbbbbbbbbb'
    """
    if isinstance(c, int):
        return c * a * b
    elif isinstance(c, java.lang.Integer):
        return a * b * int(str(c))

def fr(n):
    """
    >>> fr(5) #doctest: +ELLIPSIS
    [0, ... 3, 4]
    """
    return range(n)

if __name__ == "__main__":
    import doctest
    doctest.testmod()