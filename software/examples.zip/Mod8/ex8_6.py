# ex8_6.py

# java -jar jython ex8_6.py
# (Pdb) b 7, i==5

for i in range(20):
    print "i=%d" %i
