# ex2_2.py

import time

cnt = 10
while cnt:
    print "cnt %2d %s" %(cnt, cnt * '.')
    cnt -= 1
    time.sleep(1)
print "cnt %2d" %cnt