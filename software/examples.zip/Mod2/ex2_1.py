# ex2_1.py

total = 0
for i in range (10):
    print "i = %d" %i
    #print "i =", i
    if i % 2 == 0:
        total += i

print "total : %d" %total