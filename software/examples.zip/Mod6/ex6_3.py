from __future__ import with_statement

# ex6_3.py

import sys
import os

class FileCnt():
    def __init__(self, fname):
        self.fname = fname
        self.lines = 0
        self.bytes = 0
        with open(fname, 'r') as f:
            for line in f.readlines():
                self.lines += 1
                self.bytes += len(line)

    def linecnt(self):
        return self.lines

    def bytecnt(self, style='actual'):
        if style == 'actual':
            return self.bytes
        elif style == 'meta':
            return os.path.getsize(self.fname)
        else:
            raise ValueError("invalid style argument:  valid values are 'actual' or 'meta'")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print "usage: %s file" %sys.argv[0]
        sys.exit(1)

    fc = FileCnt(sys.argv[1])
    print "total lines in %s: %d" %(sys.argv[0], fc.linecnt())
    print "total bytes (default): %d" %fc.bytecnt()
    print "total bytes (meta):    %d" %fc.bytecnt('meta')