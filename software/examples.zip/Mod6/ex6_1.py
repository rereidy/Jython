# ex6_1.py

class MyExc(Exception):
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)

def main1():
    try:
        raise MyExc("testig MyExc")
    except MyExc, e:
        print "MyExc called: ", e.value
    except Exception, e:
        print "unknown exception: ", e
    else:
        print "no exception caught"
    finally:
        print "end of main1()"

def main2():
    try:
        raise ValueError("testig ValueError")
    except MyExc, e:
        print "MyExc called: ", e.value
    except Exception, e:
        print "unknown exception: ", e
    else:
        print "no exception caught"
    finally:
        print "end of main2()"

def main3():
    try:
        1/0
    except MyExc, e:
        print "MyExc called: ", e.value
    except Exception, e:
        print "unknown exception: ", e
    else:
        print "no exception caught"
    finally:
        print "end of main3()"

if __name__ == "__main__":
    main1()
    main2()
    main3()