from __future__ import with_statement

# ex5_1.py
print "read"
with open('README.txt', 'r') as f:
    for line in f.readlines():
        print line.rstrip("\n")

# ex5_2.py
print "read/write"
with open("/tmp/README.txt.copy", "w") as out:
    with open('README.txt', 'r') as f:
        for line in f.readlines():
            out.write(line)