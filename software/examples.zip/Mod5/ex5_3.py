# ex5_3.py

import sys

def fib(n):
    if n > 1:
        return fib(n-1) + fib(n-2)
    return n

print "fibonacci numbers\nNumber\tfib()"
for i in range(10):
    print "%2d\t%3d" %(i, fib(i))