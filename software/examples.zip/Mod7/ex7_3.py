# ex7_3.py

print "Hello Java!"