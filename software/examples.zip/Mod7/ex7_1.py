# ex7_1.py

import java

class Conv2Py():
    def conv(self, val):
        rv = None

        if isinstance(val, java.lang.Long) or isinstance(val, java.lang.Integer):
            rv = int(str(val))
        elif isinstance(val, java.lang.Float) or isinstance(val, java.lang.Double):
            #rv = float(str(val))
            rv = val+0.0

        return rv

if __name__ == "__main__":
    java_vars = {'long' : java.lang.Long(1),
                 'int'  : java.lang.Integer(2),
                 'flt'  : java.lang.Float(3.0),
                 'dbl'  : java.lang.Double(4.0)
                }

    for vtype in java_vars:
        print "Java type: %s (%s)" %(vtype, str(java_vars[vtype])), " and is a", type(java_vars[vtype])
        converted = Conv2Py().conv(java_vars[vtype])
        print "converted: %s" %(str(converted)), " and is a", type(converted)