# ex7_2.py

import java

class C():
    def __init__(self, s):
        self.mystring = s

    def pystr_conv(self):
        return java.lang.String(self.mystring)

s = "test"
print "sring=", s, " and is a", type(s)
cl = C(s)
new_s = cl.pystr_conv()
print "converted: ", new_s, " is now a", type(new_s)