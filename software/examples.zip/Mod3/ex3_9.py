# ex3_9.py

from pause import pause

lineno = 1
fp = open('README.txt', 'r')
for line in fp.readlines():
    print "%d: %s" %(lineno, line.rstrip("\n"))
    lineno += 1

pause()

import sys

lineno = 1
for l in open('README.txt', 'r').readlines():
    sys.stdout.write("%d: %s\n" %(lineno, l))
    lineno += 1

pause()

lineno = 1
fp = open('README.txt', 'r')
for line in fp.readlines():
    print >> sys.stdout, "%d: %s" %(lineno, line.rstrip("\n"))
    lineno += 1