# ex3_12.py

fp = open('README.txt', 'r')
for line in fp.readlines():
    if line.startswith("*"):
        print line.rstrip("\n")