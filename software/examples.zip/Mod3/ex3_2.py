# ex3_2.py

s = "Now is the time for all good men to come to the aid of their country."

s1 = s.rsplit("th")[0:1]
print s1

s3 = s.rpartition(" ")
print s3
