# ex3_3.py

l = ['a', 'b', 'c', 'd']
print l
l.extend(['z','x','y'])
print l

# ex3_4.py
for i in ['A', 'B', 'C']:
    l.append(i)
print l

# ex3_5.py
l.sort()
print l

# ex3_6.py
l.reverse()
print l

