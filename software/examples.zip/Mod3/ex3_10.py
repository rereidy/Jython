# ex3_10.py

import math
import time

from pause import pause

fl = [x * 1.0 for x in range(1,20)]

print "floats are: ", fl

pause()

print "math.log10()"
start_tm = time.time()
for f in fl:
    print "math.log10(%.1f) = %f" %(f, math.log10(f))
print "elapsed time: %f seconds" %(time.time() - start_tm)

pause()

import cmath
print "cmath.log10():"
start_tm = time.time()
for f in fl:
    print "cmath.log10(%.1f) = %r" %(f, cmath.log10(f))
print "elapsed time: %f seconds" %(time.time() - start_tm)