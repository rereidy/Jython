# ex9_4.py

import sys
import shutil

if len(sys.argv) < 2:
    print "usage: %s src_dir dest_dir" %sys.argv
    sys.exit(1)

print "shutil.copytree(%s, %s)" %(sys.argv[1], sys.argv[2])
shutil.copytree(sys.argv[1], sys.argv[2])



