# ex9_2.py

import os
import sys

def print_it(what, num):
    print '-' * (num+1), os.path.basename(what)

def list_dir(path, num):
    print "Listing of %s" %path

    for top_path, subdirs, files in os.walk(path):
        if len(files):
            for f in files:
                print_it(os.path.join(top_path, f), num)

        if len(subdirs):
            for s in subdirs:
                list_dir(os.path.join(top_path, s), num + 1)


if len(sys.argv) < 2:
    print "usage: %s directory" %sys.argv[0]
    sys.exit(1)


if sys.argv[1].startswith('.') and os.path.isdir(sys.argv[1]):
    der = os.path.abspath(sys.argv[1])
elif not os.path.isdir(sys.argv[1]):
    print "not a directory: %s" %sys.argv[1]
    sys.exit(1)
else:
    der = sys.argv[1]

list_dir(der, 1)
