# ex9_1b.py

import shutil
import sys
from os import getlogin, system

from pause import pause

if len(sys.argv) < 3:
    print "usage: %s src dest" %sys.argv[0]
    sys.exit(1)

_ = system("ls -l %s" %sys.argv[2])
print "shutil.copymode(%s, %s)" %(sys.argv[1], sys.argv[2])
shutil.copymode(sys.argv[1], sys.argv[2])
_ = system("ls -l %s" %sys.argv[2])

print """
*********
Ensure %s is not owned by %s
*********
""" %(sys.argv[1], getlogin())

pause()

try:
    _ = system("ls -l %s" %sys.argv[2])
    print "shutil.copymode(%s, %s)" %(sys.argv[1], sys.argv[2])
    shutil.copymode(sys.argv[1], sys.argv[2])
except OSError, e:
    print e
finally:
    _ = system("ls -l %s" %sys.argv[2])
