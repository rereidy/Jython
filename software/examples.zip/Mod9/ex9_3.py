# ex9_3.py

import os
import sys
import pprint

from ver2_6 import v2_6
v2_6()

from collections import namedtuple

if len(sys.argv) < 2:
    print "usage: %s file" %sys.argv[0]
    sys/exit(1)

stats = namedtuple('fname', 'size atime ctime mtime')
filestats = stats(size=os.stat(sys.argv[1]).st_size,
                  atime=os.stat(sys.argv[1]).st_atime,
                  ctime=os.stat(sys.argv[1]).st_ctime,
                  mtime=os.stat(sys.argv[1]).st_mtime
                 )

print "filestats object: ",
pprint.pprint(filestats)
print " File: %s" %os.path.basename(sys.argv[1])
print " Size: %d" %filestats.size
print "atime: %d" %filestats.atime
print "ctime: %d" %filestats.ctime
print "mtime: %d" %filestats.mtime
