from __future__ import print_function

animal_list = ['cat', 'dog', 'mouse', 'guinea pig', 'elephant']
print("len(animal_list)={0:d}".format(len(animal_list)))

animal_dict = {'cat' : 1, 'dog' : 2, 'mouse' : 3, 'guinea pig' : 4, 'elephant' : 5}
animal_keys = animal_dict.keys()

alpha_lower = range('a', 'z')

type(animal_list)
isinstance(animal_list, 'list')

type(animal_dict)
isinstance(animal_dict, 'dict')
type(animal_keys)
isinstance(animal_keys, 'list')
