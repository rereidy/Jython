# ex4_1.py

import re

s = "The quick, foxy brown fox-like animal."

patt = re.compile(r'\b(fox)')
m = patt.findall(s)
print m

patt = re.compile(r'\b(\w+y)\b')
m = patt.findall(s)
print m