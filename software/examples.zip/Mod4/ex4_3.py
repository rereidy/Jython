# ex3_3.py

ph = "999-999-9999"
nums = ph.split("-")
print "nums: ", nums

import re
patt = re.compile(r'(\d{3})\-(\d{3})\-(\d{4})')
m = patt.findall(ph)
print "re nums: ", nums