from __future__ import with_statement

# ex4_4.py

print "str.split() method"
with open('/usr/include/stdio.h', 'r') as f:
    for line in f.readlines():
        l = line.split()
        if len(l):
            if l[0].startswith("#include"):
                print line.rstrip("\n")

import re

patt = re.compile(r'^\s*#include')

print "\nre method"
with open('/usr/include/stdio.h', 'r') as f:
    for line in f.readlines():
        m = patt.match(line)
        if m:
            print line.rstrip("\n")

print "\nalternate re method - more generic regex combined with string searching"
patt = re.compile(r'^\s*#\w+\s+(<([^"\'<>|\b]+)>|"([^"\'<>|\b]+)")')
with open('/usr/include/stdio.h', 'r') as f:
    for line in f.readlines():
        m = patt.match(line)
        if m and "include" in line:
            print line.rstrip("\n")
