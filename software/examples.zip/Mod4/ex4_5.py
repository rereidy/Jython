from __future__ import with_statement

#################################
#
#   File:    filt1.py
#
#   Description
#
#   Demonstrate regex file filtering
#
#   Author:    Ron Reidy
#
#   Copyright 2015, Ron Reidy
#
#   This program is distributed under the GNU General Public License
#
#################################

print """
*********
from __future__ import with_statement
import re

regex_pattern = r"(\b\w{15}\b)"
patt = re.compile(regex_pattern)

lines_read, lines_matched = 0, 0
with open("/Users/rereidy/Documents/workspace/Jython/class/demos/Mod2/doi.txt", 'r') as f:
    print "filtering file: %s\n" %f.name
    for line in f.readlines():
        lines_read += 1
        words = patt.findall(line)
        if len(words):
            print "pattern ('%s') found in line number %d: " %(regex_pattern, lines_read), words
            lines_matched += 1

print "\nLines read: %d; lines matched: %d" %(lines_read, lines_matched)
*********
"""

import re
import sys

word_len = -1
if len(sys.argv) != 2:
    print "usage: %s word_length" %sys.argv[0]
    sys.exit(1)
else:
    m = re.match(r'[0-9]+', sys.argv[1])
    if not m:
        print "%s must be an integer" %sys.argv[1]
        sys.exit(1)
    else:
        word_len = int(sys.argv[1])

    regex_pattern = r"(\b\w{%d}\b)" %word_len
    patt = re.compile(regex_pattern)

    lines_read, lines_matched = 0, 0
    with open("/Users/rereidy/Documents/workspace/Jython/class/demos/Mod2/doi.txt", 'r') as f:
        print "filtering file: %s\n" %f.name
        for line in f.readlines():
            lines_read += 1
            words = patt.findall(line)
            if len(words):
                print "pattern ('%s') found %d word(s) in line number %d: %s" %(regex_pattern, len(words), lines_read, ', '.join(words))
                lines_matched += 1

    print "\nLines read: %d; lines matched: %d" %(lines_read, lines_matched)
