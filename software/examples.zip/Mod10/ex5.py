import Queue
import threading
import urllib2
import time

hosts = ["http://www.google.com", 
         "http://www.amazon.com", 
         "http://www.ibm.com", 
         "http://www.apple.com"]

queue = Queue.Queue()

class ThreadUrl(threading.Thread):
    """Threaded Url Grab"""
    def __init__(self, queue): 
        threading.Thread.__init__(self)
        self.queue = queue 
        self.exc = []
          
    def run(self):
        while True:
            host = self.queue.get()
            print "host: %s\n" %host,        
            print urllib2.urlopen(host).read(40).strip()
            self.queue.task_done()
          
def main():
    for i in range(len(hosts)):
        t = ThreadUrl(queue)
        t.setDaemon(True)
        t.start()

        for host in hosts:
            print "adding site %s to queue" %host
            queue.put(host)
            
        queue.join()
        
        if t.exc:
            print "\n".join(t.exc)

if __name__ == "__main__":
    start = time.time()
    main()
    print "Elapsed Time: %s" % (time.time() - start)
